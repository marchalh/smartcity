package be.unamur.greencity.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.Tool;

public class Inscription extends AppCompatActivity {

    private EditText nom;
    private EditText prenom;
    private EditText adresse;
    private EditText email;
    private EditText password;
    private EditText confirmation;

    private ImageButton valider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        nom = (EditText) this.findViewById(R.id.nom_inscrip);
        prenom = (EditText) this.findViewById(R.id.prenom_inscrip);
        adresse = (EditText) this.findViewById(R.id.address_inscrip);
        email = (EditText) this.findViewById(R.id.email_inscrip);
        password = (EditText) this.findViewById(R.id.pass_inscrip);
        confirmation = (EditText) this.findViewById(R.id.conf_inscrip);

        valider = (ImageButton) this.findViewById(R.id.valider_inscrip);

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean champs = verifyField(nom.getText().toString(), prenom.getText().toString(),
                        adresse.getText().toString(), email.getText().toString(),
                        password.getText().toString(), confirmation.getText().toString());

                if(champs){
                    //Todo : connect to server and verify email is unique

                    String pwdMD5 = Tool.md5(password.getText().toString());
                    //Todo : register to server

                    //Todo : intent a new activity if correct
                    Intent nextActivity = new Intent(Inscription.this, Confirmation.class);
                    nextActivity.putExtra("adresse", adresse.getText().toString());
                    startActivity(nextActivity);
                    finish();
                }
            }
        });


    }

    private boolean verifyField(String n, String p, String a, String e, String pw, String c){
        if(n.isEmpty() || p.isEmpty() || a.isEmpty() || e.isEmpty() || pw.isEmpty() || c.isEmpty()){
            Toast.makeText(Inscription.this, "Tous les champs doivent être remplis",
                    Toast.LENGTH_SHORT).show();
            return false;
        } else if(! pw.equals(c)){
            Toast.makeText(Inscription.this, "Les mots de passe ne sont pas identiques",
                    Toast.LENGTH_SHORT).show();
            return false;
        } else{
            return true;
        }
    }
}
