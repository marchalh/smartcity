package be.unamur.greencity.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import be.unamur.greencity.R;

public class Enlever extends AppCompatActivity {

    private SharedPreferences pref;

    private ImageButton ajouter;
    private ImageButton localiser;
    private ImageButton consulter;
    private ImageButton retirer;
    private ImageButton deconnecter;
    private ImageButton jardinier;

    private ImageButton valider;
    private ImageButton retour;

    private ListView plante;
    private ListView emplacement;

    private List<String> listPl;
    private List<String> listEm;
    private String planteSelec;
    private String empl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enlever);

        ajouter = (ImageButton) this.findViewById(R.id.ajoutic_enlev);
        localiser = (ImageButton) this.findViewById(R.id.viewic_enlev);
        consulter = (ImageButton) this.findViewById(R.id.attenteic_enlev);
        retirer = (ImageButton) this.findViewById(R.id.enleveric_enlev);
        deconnecter = (ImageButton) this.findViewById(R.id.decoic_enlev);
        jardinier = (ImageButton) this.findViewById(R.id.jardinieric_enlev);

        valider = (ImageButton) this.findViewById(R.id.valider_enlev);
        retour = (ImageButton) this.findViewById(R.id.retour_enlev);

        plante = (ListView) this.findViewById(R.id.plant_enlev);
        emplacement = (ListView) this.findViewById(R.id.emplacement_enlev);

        checkAdmin();

        //Clickable icons
        iconListeners(Enlever.this);

        setPlanteList();

        plante.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                view.setSelected(true);
                planteSelec = listPl.get(pos);

                //Set next ListView
                setEmplList();

                //Go to next ListView
                emplacement.setVisibility(View.VISIBLE);
                valider.setVisibility(View.VISIBLE);
                retour.setVisibility(View.VISIBLE);

                plante.setVisibility(View.GONE);
            }
        });

        emplacement.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
                view.setSelected(true);
                empl = listEm.get(pos);
            }
        });

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(empl != null){
                    //Todo : info to server to say no more plant

                    Intent nextActivity = new Intent(Enlever.this, Enlever.class);
                    startActivity(nextActivity);
                    finish();
                } else {
                    Toast.makeText(Enlever.this, "Veuillez sélectionner un emplacement",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });

        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listEm = null;
                empl = null;

                setPlanteList();
                plante.setVisibility(View.VISIBLE);

                emplacement.setVisibility(View.GONE);
                valider.setVisibility(View.GONE);
                retour.setVisibility(View.GONE);
            }
        });
    }

    private List<String> getDataPlante(){
        final List<String> list = new ArrayList<>();
        //Todo : put thing in list with what I get from server

        return list;
    }

    private List<String> getDataEmpl(String plante){
        final List<String> list = new ArrayList<>();

        //Todo : put empl corresponding to that plant

        return list;
    }

    private void setPlanteList(){
        listPl = getDataPlante();

        String[] typePlante = new String[listPl.size()];

        for(int i = 0; i < listPl.size(); i++){
            typePlante[i] = listPl.get(i);
        }

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, typePlante);
        plante.setAdapter(adapter);
    }

    private void setEmplList(){
        listEm = getDataEmpl(planteSelec);

        String[] typeEmpl = new String[listEm.size()];

        for(int i = 0; i < listEm.size(); i++){
            typeEmpl[i] = listEm.get(i);
        }

        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_expandable_list_item_1, typeEmpl);
        emplacement.setAdapter(adapter);
    }

    private void iconListeners(final Context context){
        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, AddPlant.class);
                startActivity(nextActivity);
                finish();
            }
        });

        localiser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Localisation.class);
                startActivity(nextActivity);
                finish();
            }
        });

        consulter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Reservations.class);
                startActivity(nextActivity);
                finish();
            }
        });

        retirer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Nothing to do here
            }
        });

        deconnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Logout.class);
                startActivity(nextActivity);
                finish();
            }
        });

        jardinier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Jardinier.class);
                startActivity(nextActivity);
                finish();
            }
        });
    }

    private void checkAdmin(){
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        if(pref.getBoolean("admin", true)){
            jardinier.setVisibility(View.VISIBLE);
        }
    }
}
