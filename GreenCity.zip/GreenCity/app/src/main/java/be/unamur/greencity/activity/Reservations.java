package be.unamur.greencity.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.ExpandableListAdapter;

public class Reservations extends AppCompatActivity {

    private SharedPreferences pref;

    private ImageButton ajouter;
    private ImageButton localiser;
    private ImageButton consulter;
    private ImageButton retirer;
    private ImageButton deconnecter;
    private ImageButton jardinier;

    private ExpandableListView expListView;
    private ExpandableListAdapter adapter;
    private List<String> titlesList;
    private HashMap<String, List<String>> detailsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservations);

        ajouter = (ImageButton) this.findViewById(R.id.ajoutic_reserv);
        localiser = (ImageButton) this.findViewById(R.id.viewic_reserv);
        consulter = (ImageButton) this.findViewById(R.id.attenteic_reserv);
        retirer = (ImageButton) this.findViewById(R.id.enleveric_reserv);
        deconnecter = (ImageButton) this.findViewById(R.id.decoic_reserv);
        jardinier = (ImageButton) this.findViewById(R.id.jardinieric_reserv);

        checkAdmin();

        //Clickable icons
        iconListeners(Reservations.this);

        //Fill the expandable list View
        expListView = (ExpandableListView) this.findViewById(R.id.plantEx_reserv);
        detailsList = getData();
        titlesList = new ArrayList<>(detailsList.keySet());
        adapter = new ExpandableListAdapter(this, titlesList, detailsList);

        expListView.setAdapter(adapter);

        //Clickable items
        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previous = -1;

            @Override
            public void onGroupExpand(int groupPos) {
                //The Group is expanded => Display msg ?

                //Code to collapse all groups except for the one I want to open
                if(groupPos != previous){
                    expListView.collapseGroup(previous);
                }

                previous = groupPos;
            }
        });

        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int i) {
                //The group collapsed => Display msg ?
            }
        });

        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View view, int groupPos,
                                        int childPos, long id) {

                view.setSelected(true);

                //If item selected, propose to end the booking
                AlertDialog.Builder builder = new AlertDialog.Builder(Reservations.this);
                builder.setTitle("Fin de réservation ?").setCancelable(true);

                builder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Todo : change status of reservation into the server
                    }
                });

                builder.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                return false;
            }
        });
    }

    private HashMap<String, List<String>> getData(){
        HashMap<String, List<String>> expList = new HashMap<>();

        //Todo : charger infos des plantes en attente => Nom + temps restant
        List<String> enCours = new ArrayList<>();

        //Todo : charger infos des plantes pretes => Nom + depuis quand ?
        List<String> pret = new ArrayList<>();

        //Must add backward
        expList.put("Reservations prêtes", pret);
        expList.put("Réservations en culture", enCours);

        return expList;
    }

    private void iconListeners(final Context context){
        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, AddPlant.class);
                startActivity(nextActivity);
                finish();
            }
        });

        localiser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Localisation.class);
                startActivity(nextActivity);
                finish();
            }
        });

        consulter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Reservations.class);
                startActivity(nextActivity);
                finish();
            }
        });

        retirer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Enlever.class);
                startActivity(nextActivity);
                finish();
            }
        });

        deconnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Logout.class);
                startActivity(nextActivity);
                finish();
            }
        });

        jardinier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Jardinier.class);
                startActivity(nextActivity);
                finish();
            }
        });
    }

    private void checkAdmin(){
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        if(pref.getBoolean("admin", true)){
            jardinier.setVisibility(View.VISIBLE);
        }
    }
}
