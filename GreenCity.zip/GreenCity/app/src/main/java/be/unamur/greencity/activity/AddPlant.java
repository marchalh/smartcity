package be.unamur.greencity.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.ExpandableListAdapter;

public class AddPlant extends AppCompatActivity {

    private SharedPreferences pref;

    private ImageButton ajouter;
    private ImageButton localiser;
    private ImageButton consulter;
    private ImageButton retirer;
    private ImageButton deconnecter;
    private ImageButton jardinier;

    private ImageButton valider;

    private Switch reserver;

    private ExpandableListView expListView;
    private ExpandableListAdapter adapter;
    private List<String> titlesList;
    private HashMap<String, List<String>> detailsList;

    private String plante = null;
    private String emplacement = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_plant);

        ajouter = (ImageButton) this.findViewById(R.id.ajoutic_ajout);
        localiser = (ImageButton) this.findViewById(R.id.viewic_ajout);
        consulter = (ImageButton) this.findViewById(R.id.attenteic_ajout);
        retirer = (ImageButton) this.findViewById(R.id.enleveric_ajout);
        deconnecter = (ImageButton) this.findViewById(R.id.decoic_ajout);
        jardinier = (ImageButton) this.findViewById(R.id.jardinieric_ajout);

        checkAdmin();

        //Clickable icons
        iconListeners(AddPlant.this);

        valider = (ImageButton) this.findViewById(R.id.valider_ajout);

        reserver = (Switch) this.findViewById(R.id.reserver_ajout);
        reserver.setChecked(false); //By default we don't want to book

        //Fill the expandable list View
        expListView = (ExpandableListView) this.findViewById(R.id.plantEx_ajout);
        detailsList = getData();
        titlesList = new ArrayList<String>(detailsList.keySet());
        adapter = new ExpandableListAdapter(this, titlesList, detailsList);

        expListView.setAdapter(adapter);

        //Clickable items
        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previous = -1;

            @Override
            public void onGroupExpand(int groupPos) {
                //The Group is expanded => Display msg ?

                //Code to collapse all groups except for the one I want to open
                if(groupPos != previous){
                    expListView.collapseGroup(previous);
                }

                previous = groupPos;
            }
        });

        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int i) {
                //The group collapsed => Display msg ?
            }
        });

        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View view, int groupPos,
                                        int childPos, long id) {
                // Toast.makeText(getApplicationContext(), expandableListTitle.get(groupPosition)
                // + " -> " + expandableListDetail.get(expandableListTitle.get(groupPosition))
                // .get(childPosition), Toast.LENGTH_SHORT).show();

                view.setSelected(true);

                if(titlesList.get(groupPos).equals("Choix de la plante")){
                    plante = detailsList.get(titlesList.get(groupPos)).get(childPos);
                } else if(titlesList.get(groupPos).equals("Choix de l'emplacement")){
                    emplacement = detailsList.get(titlesList.get(groupPos)).get(childPos);
                } else {
                    Toast.makeText(AddPlant.this, "Problème !", Toast.LENGTH_SHORT).show();
                }

                return false;
            }
        });

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(plante != null && emplacement != null){
                    //Todo : ajout données serveur
                } else {
                    Toast.makeText(AddPlant.this, "Veuillez sélectionner un emplacement et une plante",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private HashMap<String, List<String>> getData(){
        HashMap<String, List<String>> expList = new HashMap<>();

        //Todo : charger infos de plantes
        List<String> planteType = new ArrayList<>();

        //Todo : charger emplacements vides
        List<String> emplacements = new ArrayList<>();

        //Must add backward
        expList.put("Choix de l'emplacement", emplacements);
        expList.put("Choix de la plante", planteType);

        return expList;
    }

    private void iconListeners(final Context context){
        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Nothing to do here.
            }
        });

        localiser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Localisation.class);
                startActivity(nextActivity);
                finish();
            }
        });

        consulter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Reservations.class);
                startActivity(nextActivity);
                finish();
            }
        });

        retirer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Enlever.class);
                startActivity(nextActivity);
                finish();
            }
        });

        deconnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Logout.class);
                startActivity(nextActivity);
                finish();
            }
        });

        jardinier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Jardinier.class);
                startActivity(nextActivity);
                finish();
            }
        });
    }

    private void checkAdmin(){
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        if(pref.getBoolean("admin", true)){
            jardinier.setVisibility(View.VISIBLE);
        }
    }
}
