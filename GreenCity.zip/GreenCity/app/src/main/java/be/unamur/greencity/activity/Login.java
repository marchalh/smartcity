package be.unamur.greencity.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.Tool;

public class Login extends AppCompatActivity {

    private EditText email;
    private EditText password;
    private ImageButton inscription;
    private ImageButton valider;

    private SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //0 is for private mode
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        //Skip login
        if(pref.getString("email", "").length() != 0){
            Intent nextActivity = new Intent(Login.this, AddPlant.class);
            startActivity(nextActivity);
            finish();
        }

        setContentView(R.layout.activity_login);

        email = (EditText) this.findViewById(R.id.email_login);
        password = (EditText) this.findViewById(R.id.pass_login);

        inscription = (ImageButton) this.findViewById(R.id.inscrip_login);
        valider = (ImageButton) this.findViewById(R.id.valider_login);

        inscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Launch Inscription activity
                //Todo : intent avec champs non vides pour préremplir ?
                final Intent nextActivity = new Intent(Login.this, Inscription.class);
                startActivity(nextActivity);
            }
        });

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(email.getText().toString().isEmpty() || password.getText().toString().isEmpty()){
                    Toast.makeText(Login.this, "Veuillez remplir tous les champs",
                            Toast.LENGTH_SHORT).show();
                } else {
                    //Hash the password
                    String pwdMD5 = Tool.md5(password.getText().toString());

                    //Send to server to compare
                    //Todo : communicate with the server

                    //React with the answer
                    //Todo : change the if with the server's answer
                    if(password.getText().toString().equals("true")){
                        //Writing in Shared Preference
                        //Todo : change admin with real answer
                        writeSharedPref(email.getText().toString(), true);

                        //Todo : new activity
                        Intent nextActivity = new Intent(Login.this, AddPlant.class);
                        startActivity(nextActivity);
                        finish();
                    } else {
                        Toast.makeText(Login.this, "Le mot de passe et/ou le login n'est pas correct",
                                Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

    private void writeSharedPref(String email, boolean admin){
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("email", email);
        editor.putBoolean("admin", admin);

        editor.commit();
    }
}
