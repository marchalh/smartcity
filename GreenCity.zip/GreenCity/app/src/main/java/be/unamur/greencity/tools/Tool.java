package be.unamur.greencity.tools;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * This class is used to create methods that will be used as tools in other part of the project.
 *
 * Created by Amélie on 29-04-17.
 */

public class Tool {

    /**
     * Method used to hash in MD5 the password. This algorithme was created by reading different
     * but similar algorithms on internet.
     * @param s     the string to be hashed
     * @return String   the hashed string
     */
    public static final String md5(final String s){
        try{
            //Create MD5 hash
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());

            byte messageDigest[] = digest.digest();

            //Create hex String
            StringBuffer hexString = new StringBuffer();

            for(int i = 0; i < messageDigest.length; i++){
                String str = String.format("%02X", (0xFF & messageDigest[ i ]));
                hexString.append(str);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Algo error : " + e.getStackTrace());
        }

        return "";
    }
}
