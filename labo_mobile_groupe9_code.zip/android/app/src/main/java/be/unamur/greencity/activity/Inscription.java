package be.unamur.greencity.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.Tool;

public class Inscription extends AppCompatActivity {

    private EditText nom;
    private EditText prenom;
    private EditText adresse;
    private EditText email;
    private EditText password;
    private EditText confirmation;

    private Switch sAdmin;

    private ImageButton valider;

    private SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inscription);

        nom = (EditText) this.findViewById(R.id.nom_inscrip);
        prenom = (EditText) this.findViewById(R.id.prenom_inscrip);
        adresse = (EditText) this.findViewById(R.id.address_inscrip);
        email = (EditText) this.findViewById(R.id.email_inscrip);
        password = (EditText) this.findViewById(R.id.pass_inscrip);
        confirmation = (EditText) this.findViewById(R.id.conf_inscrip);

        sAdmin = (Switch) this.findViewById(R.id.admin_inscrip);
        sAdmin.setChecked(false);

        checkAdmin();

        valider = (ImageButton) this.findViewById(R.id.valider_inscrip);

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean champs = verifyField(nom.getText().toString(), prenom.getText().toString(),
                        adresse.getText().toString(), email.getText().toString(),
                        password.getText().toString(), confirmation.getText().toString());

                if(champs){
                    String pwdMD5 = Tool.md5(password.getText().toString());

                    RequestQueue queue = Volley.newRequestQueue(Inscription.this);

                    String url = "http://192.168.137.1:9000/inscription";

                    if(pref.getBoolean("admin", true)){
                        url += "/admin";
                    }

                    HashMap<String, String> params = new HashMap<>();

                    params.put("id", email.getText().toString());
                    params.put("forename", prenom.getText().toString());
                    params.put("name", nom.getText().toString());
                    params.put("password", pwdMD5);
                    params.put("adresse", adresse.getText().toString());

                    JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url,
                            new JSONObject(params),
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    Intent nextActivity = new Intent(Inscription.this, Confirmation.class);
                                    nextActivity.putExtra("adresse", adresse.getText().toString());
                                    startActivity(nextActivity);
                                    finish();
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    System.out.println(error.getMessage());
                                }
                            });
                    queue.add(request);
                }
            }
        });
    }

    private void checkAdmin(){
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        if(pref.getBoolean("admin", true)){
            sAdmin.setVisibility(View.VISIBLE);
        }
    }

    private boolean verifyField(String n, String p, String a, String e, String pw, String c){
        if(n.isEmpty() || p.isEmpty() || a.isEmpty() || e.isEmpty() || pw.isEmpty() || c.isEmpty()){
            Toast.makeText(Inscription.this, "Tous les champs doivent être remplis",
                    Toast.LENGTH_SHORT).show();
            return false;
        } else if(! pw.equals(c)){
            Toast.makeText(Inscription.this, "Les mots de passe ne sont pas identiques",
                    Toast.LENGTH_SHORT).show();
            return false;
        } else{
            return true;
        }
    }
}
