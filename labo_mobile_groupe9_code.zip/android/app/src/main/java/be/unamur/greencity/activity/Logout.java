package be.unamur.greencity.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import be.unamur.greencity.R;

public class Logout extends AppCompatActivity {

    private SharedPreferences pref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);
        SharedPreferences.Editor editor = pref.edit();
        editor.clear();

        editor.commit();

        RequestQueue queue = Volley.newRequestQueue(Logout.this);
        String url = "http://192.168.137.1:9000/logout";

        StringRequest request = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Intent nextActivity = new Intent(Logout.this, Login.class);
                        startActivity(nextActivity);
                        finish();
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Log.d("Error", error.getMessage());
                    }
                });

        queue.add(request);

        setContentView(R.layout.activity_logout);
    }
}
