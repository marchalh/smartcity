package be.unamur.greencity.tools;

import android.content.Context;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;

import java.util.HashMap;
import java.util.List;

import be.unamur.greencity.R;

/**
 * This class defines a custom adapter for an expandable list used in different activities.
 *
 * Created by Amélie on 30-04-17.
 */

public class ExpandableListAdapter extends BaseExpandableListAdapter{

    private Context context;
    private List<String> expListTitles;
    private HashMap<String, List<String>> expListDetails;

    public ExpandableListAdapter(Context context, List<String> expListTitles, HashMap<String,
            List<String>> expListDetails){
        this.context = context;
        this.expListTitles = expListTitles;
        this.expListDetails = expListDetails;
    }

    @Override
    public Object getChild(int listPos, int expandedListPos) {
        return this.expListDetails.get(this.expListTitles.get(listPos)).get(expandedListPos);
    }

    @Override
    public long getChildId(int listPos, int expandedListPos) {
        return expandedListPos;
    }

    @Override
    public View getChildView(int listPos, int expandedListPos, boolean isLast, View convertView,
                             ViewGroup parent) {
        final String expandedListText = (String) getChild(listPos, expandedListPos);

        if(convertView == null){
            LayoutInflater layoutInflater = (LayoutInflater) this.context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            convertView = layoutInflater.inflate(R.layout.add_plant_items, null);
        }

        TextView expandedListTextView = (TextView) convertView.findViewById(R.id.add_items);
        expandedListTextView.setText(expandedListText);

        return convertView;
    }

    @Override
    public int getChildrenCount(int listPos) {
        return this.expListDetails.get(this.expListTitles.get(listPos)).size();
    }

    @Override
    public Object getGroup(int listPos) {
        return this.expListTitles.get(listPos);
    }

    @Override
    public int getGroupCount() {
        return this.expListTitles.size();
    }

    @Override
    public long getGroupId(int listPos) {
        return listPos;
    }

    @Override
    public View getGroupView(int listPos, boolean isExp, View convertView, ViewGroup parent) {
        String listTitles = (String) getGroup(listPos);

        if(convertView == null){
            LayoutInflater layoutInflater = (LayoutInflater) this.context
                    .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            convertView = layoutInflater.inflate(R.layout.add_plant_group, null);
        }

        TextView listTitleTextView = (TextView) convertView.findViewById(R.id.add_titles);
        listTitleTextView.setTypeface(null, Typeface.BOLD);
        listTitleTextView.setText(listTitles);

        return convertView;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }

    @Override
    public boolean isChildSelectable(int listPos, int expandedListPos) {
        return true;
    }
}
