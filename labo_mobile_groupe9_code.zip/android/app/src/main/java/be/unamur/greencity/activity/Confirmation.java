package be.unamur.greencity.activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import be.unamur.greencity.R;

public class Confirmation extends AppCompatActivity {

    private TextView txtConf;
    private ImageButton retour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);

        String adresse = getIntent().getStringExtra("adresse");

        txtConf = (TextView) this.findViewById(R.id.accept_conf);
        retour = (ImageButton) this.findViewById(R.id.retour_conf);

        final String txt = "Bienvenue,\n\n\tVotre inscription a bien été prise en compte. Vous recevrez " +
                "dans les plus bref délais une carte de membre à l'adresse " + adresse + ".\n\n\tCette " +
                "carte vous permettra d'accéder aux serres de notre compagnie. Vous pouvez utiliser " +
                "dès à présent notre application en cliquant sur le bouton retour et en vous " +
                "connectant à l'aide de vos identifiants.\n\n\tN'attendez plus !";

        txtConf.setText(txt);

        retour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
