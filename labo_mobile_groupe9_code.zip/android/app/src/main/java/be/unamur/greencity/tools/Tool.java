package be.unamur.greencity.tools;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * This class is used to create methods that will be used as tools in other part of the project.
 *
 * Created by Amélie on 29-04-17.
 */

public class Tool {

    /**
     * Method used to hash in MD5 the password. This algorithme was created by reading different
     * but similar algorithms on internet.
     * @param s     the string to be hashed
     * @return String   the hashed string
     */
    public static final String md5(final String s){
        try{
            //Create MD5 hash
            MessageDigest digest = MessageDigest.getInstance("MD5");
            digest.update(s.getBytes());

            byte messageDigest[] = digest.digest();

            //Create hex String
            StringBuffer hexString = new StringBuffer();

            for(int i = 0; i < messageDigest.length; i++){
                String str = String.format("%02X", (0xFF & messageDigest[ i ]));
                hexString.append(str);
            }

            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Algo error : " + e.getStackTrace());
        }

        return "";
    }

    public static String conversionBD(String s){
        switch (s){
            case "tomate" : return "Tomate";//
            case "basilic" : return "Basilic";//
            case "chou_fleur" : return "Chou fleur";//
            case "pomme_de_terre" : return "Pomme de terre";//
            case "oignon" : return "Oignon";//
            case "poivron" : return "Poivron";//
            case "petits_pois" : return "Petits pois";//
            case "piment" : return "Piment";//
            case "carotte" : return "Carotte";//
            case "radis" : return "Radis";
            case "champignon" : return "Champignon";//
            case "salade" : return "Salade";//
            case "aubergine" : return "Aubergine";//
            default : return "Inconnu";
        }
    }

    public static String toBD(String s){
        switch (s){
            case "Tomate" : return "tomate";//
            case "Basilic" : return "basilic";//
            case "Chou fleur" : return "chou_fleur";//
            case "Pomme de terre" : return "pomme_de_terre";//
            case "Oignon" : return "oignon";//
            case "Poivron" : return "poivron";//
            case "Petits pois" : return "petits_pois";//
            case "Piment" : return "piment";//
            case "Carotte" : return "carotte";//
            case "Radis" : return "radis";
            case "Champignon" : return "champignon";//
            case "Salade" : return "salade";//
            case "Aubergine" : return "aubergine";//
            default : return "Inconnu";
        }
    }
}
