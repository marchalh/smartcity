package be.unamur.greencity.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.ExpandableListAdapter;
import be.unamur.greencity.tools.Tool;

public class AddPlant extends AppCompatActivity {

    private SharedPreferences pref;

    private ImageButton ajouter;
    private ImageButton localiser;
    private ImageButton consulter;
    private ImageButton retirer;
    private ImageButton deconnecter;
    private ImageButton jardinier;
    private ImageButton addAdmin;

    private ImageButton valider;

    private Switch reserver;

    private ExpandableListView expListView;
    private ExpandableListAdapter adapter;
    private List<String> titlesList;
    private HashMap<String, List<String>> detailsList;

    private List<String> planteType;
    private List<String> emplacements;

    private String plante = null;
    private String emplacement = null;

    private final String url_plante ="http://192.168.137.1:9000/plante_type/all";
    private final String url_emplacement = "http://192.168.137.1:9000/plante/emplacements_libres";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_plant);

        ajouter = (ImageButton) this.findViewById(R.id.ajoutic_ajout);
        localiser = (ImageButton) this.findViewById(R.id.viewic_ajout);
        consulter = (ImageButton) this.findViewById(R.id.attenteic_ajout);
        retirer = (ImageButton) this.findViewById(R.id.enleveric_ajout);
        deconnecter = (ImageButton) this.findViewById(R.id.decoic_ajout);
        jardinier = (ImageButton) this.findViewById(R.id.jardinieric_ajout);
        addAdmin = (ImageButton) this.findViewById(R.id.addAdmin_ajout);

        checkAdmin();

        //Clickable icons
        iconListeners(AddPlant.this);

        valider = (ImageButton) this.findViewById(R.id.valider_ajout);

        reserver = (Switch) this.findViewById(R.id.reserver_ajout);
        reserver.setChecked(false); //By default we don't want to book

        //Fill the expandable list View
        expListView = (ExpandableListView) this.findViewById(R.id.plantEx_ajout);
        detailsList = getData();
        titlesList = new ArrayList<String>(detailsList.keySet());
        adapter = new ExpandableListAdapter(this, titlesList, detailsList);

        expListView.setAdapter(adapter);

        //Clickable items
        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previous = -1;

            @Override
            public void onGroupExpand(int groupPos) {
                //The Group is expanded => Display msg ?

                //Code to collapse all groups except for the one I want to open
                if(groupPos != previous){
                    expListView.collapseGroup(previous);
                }

                previous = groupPos;
            }
        });

        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int i) {
                //The group collapsed => Display msg ?
            }
        });

        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View view, int groupPos,
                                        int childPos, long id) {
                view.setSelected(true);

                if(titlesList.get(groupPos).equals("Choix de la plante")){
                    plante = detailsList.get(titlesList.get(groupPos)).get(childPos);
                } else if(titlesList.get(groupPos).equals("Choix de l'emplacement")){
                    emplacement = detailsList.get(titlesList.get(groupPos)).get(childPos);
                } else {
                    Toast.makeText(AddPlant.this, "Problème !", Toast.LENGTH_SHORT).show();
                }

                return false;
            }
        });

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(plante != null && emplacement != null){
                    RequestQueue queue = Volley.newRequestQueue(AddPlant.this);

                    String rfid = pref.getString("rfid", "");

                    String url ="http://192.168.137.1:9000/plante/ajout/" + rfid;

                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date date = new Date();
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("nom", Tool.toBD(plante));
                    params.put("date_plantation", dateFormat.format(date));
                    params.put("emplacement_id", emplacement);

                    JsonObjectRequest postRequest = new JsonObjectRequest(Request.Method.POST, url,
                            new JSONObject(params),
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    //Log.d("Response", response);
                                    Intent reload = new Intent(AddPlant.this, AddPlant.class);
                                    startActivity(reload);
                                    finish();
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    //Log.d("Error.Response", error.getMessage());
                                }
                            });

                    queue.add(postRequest);

                    if(reserver.isChecked()){
                        url = "http://192.168.137.1:9000/plante/reserver/" + rfid;

                        HashMap<String, String> param = new HashMap<>();

                        param.put("emplacement", emplacement);
                        param.put("plante_name", Tool.toBD(plante));

                        System.out.println(new JSONObject(param));

                        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url,
                                new JSONObject(param),
                                new Response.Listener<JSONObject>() {
                                    @Override
                                    public void onResponse(JSONObject response) {

                                    }
                                },
                                new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        //Log.d("Error", error.getMessage());
                                    }
                                });

                        queue.add(request);
                    }

                } else {
                    Toast.makeText(AddPlant.this, "Veuillez sélectionner un emplacement et une plante",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private HashMap<String, List<String>> getData(){
        HashMap<String, List<String>> expList = new HashMap<>();

        //Sending request to server and fill the lists
        planteType = new ArrayList<>();
        sendGetReceiveJsonArray(url_plante);

        emplacements = new ArrayList<>();
        sendGetReceiveJsonArray(url_emplacement);

        //Must add backward
        expList.put("Choix de l'emplacement", emplacements);
        expList.put("Choix de la plante", planteType);

        return expList;
    }

    private void iconListeners(final Context context){
        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Nothing to do here.
            }
        });

        localiser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Localisation.class);
                startActivity(nextActivity);
                finish();
            }
        });

        consulter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Reservations.class);
                startActivity(nextActivity);
                finish();
            }
        });

        retirer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Enlever.class);
                startActivity(nextActivity);
                finish();
            }
        });

        deconnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Logout.class);
                startActivity(nextActivity);
                finish();
            }
        });

        jardinier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Jardinier.class);
                startActivity(nextActivity);
                finish();
            }
        });

        addAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Inscription.class);
                startActivity(nextActivity);
            }
        });
    }

    private void checkAdmin(){
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        if(pref.getBoolean("admin", true)){
            jardinier.setVisibility(View.VISIBLE);
            addAdmin.setVisibility(View.VISIBLE);
        }
    }

    private void sendGetReceiveJsonArray(final String url){
        RequestQueue queue = Volley.newRequestQueue(AddPlant.this);

        JsonArrayRequest request_json = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            //Process os success response
                            for(int i = 0; i < response.length(); i++){
                                JSONObject object = response.getJSONObject(i);

                                treatResponse(url, object);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.e("Error: ", error.getMessage());
            }
        });
        // Add the request to the RequestQueue.
        queue.add(request_json);
    }


    private void treatResponse(String url, JSONObject object){
        if(url.equals(url_plante)){
            try{
                String planteName = object.getString("nom");
                planteType.add(Tool.conversionBD(planteName));

            } catch (JSONException e) {
                e.printStackTrace();
            }

        } else if (url.equals(url_emplacement)){
            try{
                String idEmplacement = object.getString("id");
                emplacements.add(idEmplacement);

            } catch (JSONException e) {
                e.printStackTrace();
            }

        } else {
            System.out.println("Erreuuuuuuur !");
        }
    }
}
