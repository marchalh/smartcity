package be.unamur.greencity.activity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.CookieHandler;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.util.HashMap;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.PersistentCookieStore;
import be.unamur.greencity.tools.Tool;

import static android.provider.ContactsContract.CommonDataKinds.Website.URL;

public class Login extends AppCompatActivity {

    private EditText email;
    private EditText password;
    private ImageButton inscription;
    private ImageButton valider;

    private SharedPreferences pref;

    private CookieManager cookie;

    private static final int LOCATION_PERMISSION = 1;
    private static final int LOCATION_COARSE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if(ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)){
                Toast.makeText(this, "Permission nécessaire", Toast.LENGTH_SHORT).show();
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_PERMISSION);

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_COARSE);
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_PERMISSION);

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_COARSE);
            }

        }

        //0 is for private mode
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        //Skip login
        if(pref.getString("email", "").length() != 0){
            // Instantiate the RequestQueue.
            RequestQueue queue = Volley.newRequestQueue(Login.this);
            String url ="http://192.168.137.1:9000/login";
            HashMap<String, String> params = new HashMap<>();

            final String pwdMD5 = pref.getString("pass", "");

            params.put("id", pref.getString("email", ""));
            params.put("password", pwdMD5);

            JsonObjectRequest request_json = new JsonObjectRequest(Request.Method.GET, url,
                    new JSONObject(params),
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {
                            Intent nextActivity = new Intent(Login.this, AddPlant.class);
                            startActivity(nextActivity);
                            finish();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            VolleyLog.e("Error: ", error.getMessage());
                        }
                    });
            // Add the request to the RequestQueue.
            queue.add(request_json);
        } else {
            SharedPreferences.Editor editor = pref.edit();
            editor.putBoolean("admin", false);

            editor.commit();
        }

        setContentView(R.layout.activity_login);

        email = (EditText) this.findViewById(R.id.email_login);
        password = (EditText) this.findViewById(R.id.pass_login);

        inscription = (ImageButton) this.findViewById(R.id.inscrip_login);
        valider = (ImageButton) this.findViewById(R.id.valider_login);

        inscription.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Launch Inscription activity
                final Intent nextActivity = new Intent(Login.this, Inscription.class);
                startActivity(nextActivity);
            }
        });

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(email.getText().toString().isEmpty() || password.getText().toString().isEmpty()){
                    Toast.makeText(Login.this, "Veuillez remplir tous les champs",
                            Toast.LENGTH_SHORT).show();
                } else {
                    //Hash the password
                    final String pwdMD5 = Tool.md5(password.getText().toString());

                    //Send to server to compare
                    // Instantiate the RequestQueue.
                    RequestQueue queue = Volley.newRequestQueue(Login.this);
                    String url = "http://192.168.137.1:9000/login";
                    HashMap<String, String> params = new HashMap<>();

                    params.put("id", email.getText().toString());
                    params.put("password", pwdMD5);

                    JsonObjectRequest request_json = new JsonObjectRequest(Request.Method.POST, url,
                            new JSONObject(params),
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {
                                    try {
                                        //Process os success response
                                        int admin = response.getInt("admin"); //Admin = 1, Lambda = 0
                                        String rfid = response.getString("rfid");

                                        //Process datas
                                        processData(admin, rfid, pwdMD5);

                                    } catch (JSONException e) {
                                        e.printStackTrace();
                                    }
                                }
                            },
                            new Response.ErrorListener() {
                                @Override
                                public void onErrorResponse(VolleyError error) {
                                    VolleyLog.e("Error: ", error.getMessage());
                                }
                            });
                    // Add the request to the RequestQueue.
                    queue.add(request_json);
                }
            }
        });
    }

    private void processData(int admin, String rfid, String pwd){
        if(admin == 0){
            writeSharedPref(email.getText().toString(), pwd, rfid, false);

            Intent nextActivity = new Intent(Login.this, AddPlant.class);
            startActivity(nextActivity);
            finish();
        } else if (admin == 1){
            writeSharedPref(email.getText().toString(), pwd, rfid, true);

            Intent nextActivity = new Intent(Login.this, AddPlant.class);
            startActivity(nextActivity);
            finish();
        } else {
            Toast.makeText(Login.this, "Le mot de passe et/ou le login n'est pas correct",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void writeSharedPref(String email, String mdp, String rfid, boolean admin){
        SharedPreferences.Editor editor = pref.edit();

        editor.putString("email", email);
        editor.putString("pass", mdp);
        editor.putString("rfid", rfid);
        editor.putBoolean("admin", admin);

        editor.commit();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {

            case LOCATION_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(Login.this, "Permission Granted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Login.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }
                break;

            case LOCATION_COARSE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(Login.this, "Permission Granted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Login.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
}
