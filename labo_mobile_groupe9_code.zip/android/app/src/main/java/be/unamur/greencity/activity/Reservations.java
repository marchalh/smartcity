package be.unamur.greencity.activity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.util.Log;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.ExpandableListAdapter;
import be.unamur.greencity.tools.Tool;

public class Reservations extends AppCompatActivity {

    private SharedPreferences pref;

    private ImageButton ajouter;
    private ImageButton localiser;
    private ImageButton consulter;
    private ImageButton retirer;
    private ImageButton deconnecter;
    private ImageButton jardinier;
    private ImageButton addAdmin;

    private ExpandableListView expListView;
    private ExpandableListAdapter adapter;
    private List<String> titlesList;
    private HashMap<String, List<String>> detailsList;

    private List<String> enCours;
    private List<String> pret;

    private String nom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservations);

        ajouter = (ImageButton) this.findViewById(R.id.ajoutic_reserv);
        localiser = (ImageButton) this.findViewById(R.id.viewic_reserv);
        consulter = (ImageButton) this.findViewById(R.id.attenteic_reserv);
        retirer = (ImageButton) this.findViewById(R.id.enleveric_reserv);
        deconnecter = (ImageButton) this.findViewById(R.id.decoic_reserv);
        jardinier = (ImageButton) this.findViewById(R.id.jardinieric_reserv);
        addAdmin = (ImageButton) this.findViewById(R.id.addAdmin_reserv);

        checkAdmin();

        //Clickable icons
        iconListeners(Reservations.this);

        //Fill the expandable list View
        expListView = (ExpandableListView) this.findViewById(R.id.plantEx_reserv);
        detailsList = getData();
        titlesList = new ArrayList<>(detailsList.keySet());
        adapter = new ExpandableListAdapter(this, titlesList, detailsList);

        expListView.setAdapter(adapter);

        //Clickable items
        expListView.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previous = -1;

            @Override
            public void onGroupExpand(int groupPos) {
                //The Group is expanded => Display msg ?

                //Code to collapse all groups except for the one I want to open
                if(groupPos != previous){
                    expListView.collapseGroup(previous);
                }

                previous = groupPos;
            }
        });

        expListView.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int i) {
                //The group collapsed => Display msg ?
            }
        });

        expListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View view, int groupPos,
                                        int childPos, long id) {
                String name = detailsList.get(titlesList.get(groupPos)).get(childPos);
                String[] namesplit = name.split("•");
                nom = namesplit[1];

                view.setSelected(true);

                //If item selected, propose to end the booking
                AlertDialog.Builder builder = new AlertDialog.Builder(Reservations.this);
                builder.setTitle("Fin de réservation ?").setCancelable(true);

                builder.setPositiveButton("Oui", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        postJSon();

                    }
                });

                builder.setNegativeButton("Non", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();

                return false;
            }
        });
    }

    private HashMap<String, List<String>> getData(){
        HashMap<String, List<String>> expList = new HashMap<>();

        enCours = new ArrayList<>();
        pret = new ArrayList<>();

        getJSon();

        //Must add backward
        expList.put("Reservations prêtes", pret);
        expList.put("Réservations en culture", enCours);

        return expList;
    }

    private void iconListeners(final Context context){
        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, AddPlant.class);
                startActivity(nextActivity);
                finish();
            }
        });

        localiser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Localisation.class);
                startActivity(nextActivity);
                finish();
            }
        });

        consulter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Reservations.class);
                startActivity(nextActivity);
                finish();
            }
        });

        retirer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Enlever.class);
                startActivity(nextActivity);
                finish();
            }
        });

        deconnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Logout.class);
                startActivity(nextActivity);
                finish();
            }
        });

        jardinier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Jardinier.class);
                startActivity(nextActivity);
                finish();
            }
        });

        addAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Inscription.class);
                startActivity(nextActivity);
            }
        });
    }

    private void checkAdmin(){
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        if(pref.getBoolean("admin", true)){
            jardinier.setVisibility(View.VISIBLE);
            addAdmin.setVisibility(View.VISIBLE);
        }
    }

    private void getJSon(){
        RequestQueue queue = Volley.newRequestQueue(Reservations.this);

        String rfid = pref.getString("rfid", "");
        String url = "http://192.168.137.1:9000/plante/reservees/" + rfid;

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try {
                            for (int i = 0; i < response.length(); i++) {
                                JSONObject object = response.getJSONObject(i);
                                treatRequest(object);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Log.d("Error", error.getMessage());
                    }
                });

        queue.add(request);
    }

    private void treatRequest(JSONObject object){
        try {
            String typePlante = object.getString("name");
            String idEmplacement = object.getString("id_emplacement");
            int ready = object.getInt("pret");

            if(ready == 0){
                int timeRemaining = object.getInt("remaining");

                //Ajout liste pas ready
                String text = "•" + Tool.conversionBD(typePlante) + "•" + "\n\tEmplacement : " + idEmplacement
                        + "\n\tTemps restant : " + timeRemaining;

                enCours.add(text);

            } else if(ready == 1) {
                //Ajout liste ready
                String text = "•" + Tool.conversionBD(typePlante) + "•" + "\n\t" + "emplacement : " + idEmplacement;

                pret.add(text);
            } else {
                System.out.println("ERREUUUUUUR");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void postJSon(){
        RequestQueue queue = Volley.newRequestQueue(Reservations.this);

        String rfid = pref.getString("rfid", "");
        String url = "http://192.168.137.1:9000/plante/reserver/annuler/" + rfid;

        HashMap<String, String> params = new HashMap<>();
        params.put("nom", Tool.toBD(nom));

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url,
                new JSONObject(params),
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        queue.add(request);
    }
}
