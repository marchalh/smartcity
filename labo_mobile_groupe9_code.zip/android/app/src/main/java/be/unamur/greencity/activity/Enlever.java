package be.unamur.greencity.activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import be.unamur.greencity.R;
import be.unamur.greencity.tools.ExpandableListAdapter;
import be.unamur.greencity.tools.Tool;

public class Enlever extends AppCompatActivity {

    private SharedPreferences pref;

    private ImageButton ajouter;
    private ImageButton localiser;
    private ImageButton consulter;
    private ImageButton retirer;
    private ImageButton deconnecter;
    private ImageButton jardinier;
    private ImageButton addAdmin;

    private ImageButton valider;
    private ImageButton retour;

    private ExpandableListView plante;
    private ExpandableListView emplacement;

    private ExpandableListAdapter adapter;

    private List<String> planteListe;
    private List<String> emplacementListe;
    private HashMap<String, List<String>> detailList;
    private List<String> titleList;

    private HashMap<String, String> memory = new HashMap<>();

    private String planteSelec;
    private String emplaSelec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enlever);

        ajouter = (ImageButton) this.findViewById(R.id.ajoutic_enlev);
        localiser = (ImageButton) this.findViewById(R.id.viewic_enlev);
        consulter = (ImageButton) this.findViewById(R.id.attenteic_enlev);
        retirer = (ImageButton) this.findViewById(R.id.enleveric_enlev);
        deconnecter = (ImageButton) this.findViewById(R.id.decoic_enlev);
        jardinier = (ImageButton) this.findViewById(R.id.jardinieric_enlev);
        addAdmin = (ImageButton) this.findViewById(R.id.addAdmin_enlev);

        valider = (ImageButton) this.findViewById(R.id.valider_enlev);
        retour = (ImageButton) this.findViewById(R.id.retour_enlev);

        checkAdmin();

        //Clickable icons
        iconListeners(Enlever.this);

        //Set lists
        plante = (ExpandableListView) this.findViewById(R.id.plantEx_enlev);
        emplacement = (ExpandableListView) this.findViewById(R.id.plantEx_enlev2);
        detailList = getData();
        titleList = new ArrayList<>(detailList.keySet());

        adapter = new ExpandableListAdapter(this, titleList, detailList);
        plante.setAdapter(adapter);

        //Clickable items
        plante.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previous = -1;

            @Override
            public void onGroupExpand(int groupPos) {
                //The Group is expanded => Display msg ?

                //Code to collapse all groups except for the one I want to open
                if(groupPos != previous){
                    plante.collapseGroup(previous);
                }

                previous = groupPos;
            }
        });

        plante.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int i) {
                //The group collapsed => Display msg ?
            }
        });

        plante.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View view, int groupPos,
                                        int childPos, long id) {
                view.setSelected(true);

                planteSelec = detailList.get(titleList.get(groupPos)).get(childPos);
                detailList = getEmpla();
                titleList = new ArrayList<String>(detailList.keySet());

                adapter = new ExpandableListAdapter(Enlever.this, titleList, detailList);
                emplacement.setAdapter(adapter);

                emplacement.setVisibility(View.VISIBLE);
                plante.setVisibility(View.GONE);

                return false;
            }
        });

        //Clickable items
        emplacement.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {
            int previous = -1;

            @Override
            public void onGroupExpand(int groupPos) {
                //The Group is expanded => Display msg ?

                //Code to collapse all groups except for the one I want to open
                if(groupPos != previous){
                    plante.collapseGroup(previous);
                }

                previous = groupPos;
            }
        });

        emplacement.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int i) {
                //The group collapsed => Display msg ?
            }
        });

        emplacement.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View view, int groupPos,
                                        int childPos, long id) {
                view.setSelected(true);

                emplaSelec = detailList.get(titleList.get(groupPos)).get(childPos);
                String url = "http://192.168.137.1:9000/plante/recolte/" + emplaSelec;

                sendRequest(url);

                return false;
            }
        });
    }

    private void iconListeners(final Context context){
        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, AddPlant.class);
                startActivity(nextActivity);
                finish();
            }
        });

        localiser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Localisation.class);
                startActivity(nextActivity);
                finish();
            }
        });

        consulter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Reservations.class);
                startActivity(nextActivity);
                finish();
            }
        });

        retirer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Nothing to do here
            }
        });

        deconnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Logout.class);
                startActivity(nextActivity);
                finish();
            }
        });

        jardinier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Jardinier.class);
                startActivity(nextActivity);
                finish();
            }
        });

        addAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Inscription.class);
                startActivity(nextActivity);
            }
        });
    }

    private void checkAdmin(){
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        if(pref.getBoolean("admin", true)){
            jardinier.setVisibility(View.VISIBLE);
            addAdmin.setVisibility(View.VISIBLE);
        }
    }

    private HashMap<String, List<String>> getData(){
        HashMap<String, List<String>> expList = new HashMap<>();

        planteListe = new ArrayList<>();
        sendGetReceiveJson("http://192.168.137.1:9000/plante/all/");

        expList.put("Type de plante retirée", planteListe);

        return expList;
    }

    private HashMap<String, List<String>> getEmpla(){
        HashMap<String, List<String>> expList = new HashMap<>();

        emplacementListe = new ArrayList<>();

        for(String id : memory.keySet()){
            if(memory.get(id).equals(Tool.toBD(planteSelec))){
                emplacementListe.add(id);
            }
        }

        expList.put("Emplacement de la plante", emplacementListe);

        return expList;
    }

    private void sendGetReceiveJson(String url){
        RequestQueue queue = Volley.newRequestQueue(Enlever.this);

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try{
                            for(int i = 0; i < response.length(); i++){
                                JSONObject object = response.getJSONObject(i);
                                treatResponse(object);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        queue.add(request);
    }

    private void treatResponse(JSONObject object){
        try{
            String name = object.getString("nom");
            String idEmplacement = object.getString("emplacement_id");
            System.out.println(name);
            System.out.println(idEmplacement);

            if(!planteListe.contains(name)){
                planteListe.add(Tool.conversionBD(name));
            }

            memory.put(idEmplacement, name);

        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void sendRequest(String url){
        RequestQueue queue = Volley.newRequestQueue(Enlever.this);

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });

        queue.add(request);
    }
}
