package be.unamur.greencity.activity;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.location.Location;
import android.location.LocationManager;
import android.provider.Settings;
import android.provider.SyncStateContract;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

import be.unamur.greencity.R;

public class Localisation extends FragmentActivity implements OnMapReadyCallback {

    private SharedPreferences pref;

    private ImageButton ajouter;
    private ImageButton localiser;
    private ImageButton consulter;
    private ImageButton retirer;
    private ImageButton deconnecter;
    private ImageButton jardinier;
    private ImageButton addAdmin;

    private GoogleMap mMap;

    private String urlAllPlante = "http://192.168.137.1:9000/plante/lister/all";
    private String urlVide = "http://192.168.137.1:9000/plante/emplacements_libres";

    private static final int LOCATION_PERMISSION = 1;
    private static final int LOCATION_COARSE = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_localisation);

        ajouter = (ImageButton) this.findViewById(R.id.ajoutic_locali);
        localiser = (ImageButton) this.findViewById(R.id.viewic_locali);
        consulter = (ImageButton) this.findViewById(R.id.attenteic_locali);
        retirer = (ImageButton) this.findViewById(R.id.enleveric_locali);
        deconnecter = (ImageButton) this.findViewById(R.id.decoic_locali);
        jardinier = (ImageButton) this.findViewById(R.id.jardinieric_locali);
        addAdmin = (ImageButton) this.findViewById(R.id.addAdmin_locali);

        checkAdmin();

        //Clickable icons
        iconListeners(Localisation.this);

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        //Adding markers at greenhouses places
        localiJSON(urlAllPlante);
        localiJSON(urlVide);

        //Verify that we have the authorisation to use current location
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if(ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)){
                Toast.makeText(this, "Permission nécessaire", Toast.LENGTH_SHORT).show();
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_PERMISSION);

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_COARSE);
            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},LOCATION_PERMISSION);

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},LOCATION_COARSE);
            }

        }

        mMap.setMyLocationEnabled(true);

        //Zoom to user's location
        Location location = mMap.getMyLocation();
        if(location != null){
            LatLng myLoc = new LatLng(location.getLatitude(), location.getLongitude());
            mMap.moveCamera(CameraUpdateFactory.newLatLng(myLoc));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        switch (requestCode) {

            case LOCATION_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(Localisation.this, "Permission Granted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Localisation.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }
                break;

            case LOCATION_COARSE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(Localisation.this, "Permission Granted!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(Localisation.this, "Permission Denied!", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    private void localiJSON(final String url){
        RequestQueue queue = Volley.newRequestQueue(Localisation.this);

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        try{
                            for(int i = 0; i < response.length(); i++){
                                JSONObject object = response.getJSONObject(i);

                                marksFromJSON(url, object);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        //Log.d("Error", error.getMessage());
                    }
                });

        queue.add(request);
    }

    private void marksFromJSON(String url, JSONObject object){
        try {
            if (url.equals(urlAllPlante)) {
                String name = object.getString("nom");
                String idEmplacement = object.getString("emplacement_id");
                double latitude = Double.parseDouble(object.getString("lat").replace(",", "."));
                double longitude = Double.parseDouble(object.getString("longitude").replace(",", "."));

                System.out.println("Plante = " + name);

                Marker newMarker;
                BitmapDescriptor ic;
                LatLng pos = new LatLng(latitude, longitude);

                switch (name){
                    case "tomate" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_tomate);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "basilic" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_basilic);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "chou_fleur" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_choufleur);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "pomme_de_terre" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_patate);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "oignon" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_oignon);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "poivron" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_poivron);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "petits_pois" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_petitpois);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "piment" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_piment);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "carotte" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_carotte);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "radis" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_radis);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "champignon" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_champignon);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "salade" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_salade);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    case "aubergine" :
                        ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_aubergine);
                        newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                        //Todo : add title and snippet to options

                        break;

                    default :
                        System.out.println("Erreur carte ?");
                }
            } else if(url.equals(urlVide)){
                String idEmplacement = object.getString("id");
                double latitude = Double.parseDouble(object.getString("lat").replace(",", "."));
                double longitude = Double.parseDouble(object.getString("longitude").replace(",", "."));

                BitmapDescriptor ic = BitmapDescriptorFactory.fromResource(R.mipmap.ic_empty);
                LatLng pos = new LatLng(latitude, longitude);

                Marker newMarker = mMap.addMarker(new MarkerOptions().position(pos).icon(ic));
                //Todo : add title and snippet to options
            } else {
                System.out.println("Erreur ?");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void iconListeners(final Context context){
        ajouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, AddPlant.class);
                startActivity(nextActivity);
                finish();
            }
        });

        localiser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Localisation.class);
                startActivity(nextActivity);
                finish();
            }
        });

        consulter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Reservations.class);
                startActivity(nextActivity);
                finish();
            }
        });

        retirer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Enlever.class);
                startActivity(nextActivity);
                finish();
            }
        });

        deconnecter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Logout.class);
                startActivity(nextActivity);
                finish();
            }
        });

        jardinier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Jardinier.class);
                startActivity(nextActivity);
                finish();
            }
        });

        addAdmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent nextActivity = new Intent(context, Inscription.class);
                startActivity(nextActivity);
            }
        });
    }

    private void checkAdmin(){
        pref = getApplicationContext().getSharedPreferences("GreenPref" , 0);

        if(pref.getBoolean("admin", true)){
            jardinier.setVisibility(View.VISIBLE);
            addAdmin.setVisibility(View.VISIBLE);
        }
    }
}
