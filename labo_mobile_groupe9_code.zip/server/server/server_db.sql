/*
Navicat MySQL Data Transfer

Source Server         : mobile
Source Server Version : 50717
Source Host           : localhost:3306
Source Database       : server_db

Target Server Type    : MYSQL
Target Server Version : 50717
File Encoding         : 65001

Date: 2017-05-19 16:48:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `emplacement`
-- ----------------------------
DROP TABLE IF EXISTS `emplacement`;
CREATE TABLE `emplacement` (
  `id` varchar(60) NOT NULL,
  `lat` float DEFAULT NULL,
  `longitude` float DEFAULT NULL,
  `raspberry_id` varchar(40) DEFAULT NULL,
  `free` tinyint(1) DEFAULT NULL,
  `access_user` tinyint(1) NOT NULL DEFAULT '1',
  `responsable` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `responsable` (`responsable`),
  CONSTRAINT `emplacement_ibfk_1` FOREIGN KEY (`responsable`) REFERENCES `users` (`rfid_tag_nbr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of emplacement
-- ----------------------------
INSERT INTO `emplacement` VALUES ('e01', '50.466', '4.85709', '192.168.137.2', '0', '1', 'u50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e02', '50.4668', '4.8571', '192.168.137.1', '0', '1', 'u50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e03', '50.467', '4.85709', '192.168.137.104', '0', '1', 'u50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e04', '50.468', '4.8571', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e05', '50.469', '4.85721', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e06', '50.469', '4.85721', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e07', '50.47', '4.85721', '192.168.137.104', '1', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e08', '50.469', '4.85721', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e09', '50.469', '4.85721', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e10', '50.47', '4.85721', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e11', '50.469', '4.85721', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e12', '50.469', '4.85721', '192.168.137.104', '1', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e13', '50.47', '4.85721', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e14', '50.469', '4.85721', '192.168.137.104', '0', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e15', '50.469', '4.85721', '192.168.137.104', '1', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e16', '50.47', '4.85721', '192.168.137.104', '1', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `emplacement` VALUES ('e17', '50.469', '4.85721', '192.168.137.104', '1', '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');

-- ----------------------------
-- Table structure for `meteo`
-- ----------------------------
DROP TABLE IF EXISTS `meteo`;
CREATE TABLE `meteo` (
  `ensoleillement` int(11) DEFAULT NULL,
  `temperature` int(11) DEFAULT NULL,
  `id_station` varchar(60) NOT NULL,
  `humidite` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_station`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of meteo
-- ----------------------------
INSERT INTO `meteo` VALUES ('832', '24', '192.168.137.255', '46');

-- ----------------------------
-- Table structure for `plante`
-- ----------------------------
DROP TABLE IF EXISTS `plante`;
CREATE TABLE `plante` (
  `nom` varchar(60) NOT NULL,
  `emplacement_id` varchar(60) NOT NULL,
  `luminosite` float DEFAULT NULL,
  `ph` float DEFAULT NULL,
  `humidite` float DEFAULT NULL,
  `temperature` float DEFAULT NULL,
  `date_plantation` date DEFAULT NULL,
  `date_recolte_calculee` date DEFAULT NULL,
  `date_recolte` date DEFAULT NULL,
  `a_recolter` tinyint(1) NOT NULL DEFAULT '0',
  `user_rfid` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`emplacement_id`),
  KEY `user_rfid` (`user_rfid`),
  KEY `nom` (`nom`),
  CONSTRAINT `plante_ibfk_1` FOREIGN KEY (`emplacement_id`) REFERENCES `emplacement` (`id`),
  CONSTRAINT `plante_ibfk_2` FOREIGN KEY (`user_rfid`) REFERENCES `users` (`rfid_tag_nbr`),
  CONSTRAINT `plante_ibfk_3` FOREIGN KEY (`nom`) REFERENCES `plante_type` (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of plante
-- ----------------------------
INSERT INTO `plante` VALUES ('aubergine', 'e01', null, null, null, null, '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('aubergine', 'e02', '167', '9.7344', '83.8806', '24.2138', '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('salade', 'e03', '383', '15.8932', '-40.2', '25.7692', '2017-05-12', '2017-08-20', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('salade', 'e04', '322', '-1.889', '56.6248', '23.9916', '2017-11-23', '2017-05-03', null, '0', 'uzohiDgjtjD20NmAcRRATIu1W3R6G3By');
INSERT INTO `plante` VALUES ('champignon', 'e05', null, null, null, null, '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('pomme_de_terre', 'e06', null, null, null, null, '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('carotte', 'e08', null, null, null, null, '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('chou_fleur', 'e09', null, null, null, null, '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('petits_pois', 'e10', null, null, null, null, '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('piment', 'e11', null, null, null, null, '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('poivron', 'e13', null, null, null, null, '2017-05-11', '2017-04-21', null, '0', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');
INSERT INTO `plante` VALUES ('carotte', 'e14', null, null, null, null, '2017-05-11', '2017-05-12', null, '1', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh');

-- ----------------------------
-- Table structure for `plante_type`
-- ----------------------------
DROP TABLE IF EXISTS `plante_type`;
CREATE TABLE `plante_type` (
  `nom` varchar(60) NOT NULL,
  `luminosite_min` int(11) DEFAULT NULL,
  `luminosite_max` int(11) DEFAULT NULL,
  `ph_min` int(11) DEFAULT NULL,
  `ph_max` int(11) DEFAULT NULL,
  `humidite_min` int(11) DEFAULT NULL,
  `humidite_max` int(11) DEFAULT NULL,
  `temperature_min` int(11) DEFAULT NULL,
  `temperature_max` int(11) DEFAULT NULL,
  `chemical` varchar(255) DEFAULT NULL,
  `mois_plantation_debut` enum('janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre','decembre') DEFAULT NULL,
  `mois_plantation_fin` enum('janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre','decembre') DEFAULT NULL,
  `mois_recolte_debut` enum('janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre','decembre') DEFAULT NULL,
  `mois_recolte_fin` enum('janvier','fevrier','mars','avril','mai','juin','juillet','aout','septembre','octobre','novembre','decembre') DEFAULT NULL,
  `temps_maturite` int(11) DEFAULT NULL,
  PRIMARY KEY (`nom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of plante_type
-- ----------------------------
INSERT INTO `plante_type` VALUES ('aubergine', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('basilic', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('carotte', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('champignon', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('chou_fleur', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('oignon', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('petits_pois', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('piment', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('poivron', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('pomme_de_terre', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('radis', '0', '100', '4', '9', '20', '90', '4', '35', null, 'mars', 'avril', 'septembre', 'novembre', '214');
INSERT INTO `plante_type` VALUES ('salade', '25', '100', '5', '9', '20', '100', '5', '40', null, 'mars', 'juin', 'aout', 'septembre', '100');
INSERT INTO `plante_type` VALUES ('tomate', '25', '100', '5', '9', '20', '100', '5', '40', null, 'avril', 'juin', 'aout', 'septembre', '200');

-- ----------------------------
-- Table structure for `reservation`
-- ----------------------------
DROP TABLE IF EXISTS `reservation`;
CREATE TABLE `reservation` (
  `user_id` varchar(60) NOT NULL,
  `plante_name` varchar(60) DEFAULT NULL,
  `date_reservation` date DEFAULT NULL,
  `emplacement_id` varchar(60) NOT NULL,
  PRIMARY KEY (`emplacement_id`,`user_id`),
  KEY `user_id` (`user_id`),
  KEY `plante_name` (`plante_name`),
  CONSTRAINT `reservation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`rfid_tag_nbr`),
  CONSTRAINT `reservation_ibfk_2` FOREIGN KEY (`plante_name`) REFERENCES `plante` (`nom`),
  CONSTRAINT `reservation_ibfk_3` FOREIGN KEY (`emplacement_id`) REFERENCES `emplacement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of reservation
-- ----------------------------
INSERT INTO `reservation` VALUES ('a50LoPHk4jaScGN2Optczjqo6byjoNgh', 'salade', '2017-05-12', 'e03');
INSERT INTO `reservation` VALUES ('a50LoPHk4jaScGN2Optczjqo6byjoNgh', 'Piment', '2017-05-11', 'e11');
INSERT INTO `reservation` VALUES ('a50LoPHk4jaScGN2Optczjqo6byjoNgh', 'poivron', '2017-05-11', 'e13');
INSERT INTO `reservation` VALUES ('a50LoPHk4jaScGN2Optczjqo6byjoNgh', 'carotte', '2017-05-11', 'e14');

-- ----------------------------
-- Table structure for `users`
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` varchar(60) NOT NULL,
  `rfid_tag_nbr` varchar(60) NOT NULL,
  `forename` varchar(60) DEFAULT NULL,
  `name` varchar(60) DEFAULT NULL,
  `password` varchar(60) NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `rfid_tag_nbr` (`rfid_tag_nbr`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('ag@out.com', 'aGatHcwOZfxoHsWAIQ1UP2SolTtktuQW', 'Marchal', 'Agnes', '6BD48B1E57856137037BFEE4DEC8D57F', 'rue de France 23', '1');
INSERT INTO `users` VALUES ('al@mail', 'a50LoPHk4jaScGN2Optczjqo6byjoNgh', 'Amélie', 'Lemal', '347A11D1E4D12E53AC0B397425571ACA', 'coucou', '1');
INSERT INTO `users` VALUES ('ale@mail', 'u50LoPHk4jaScGN2Optczjqo6byjoNgh', 'Amélie ', 'Lemal ', '347A11D1E4D12E53AC0B397425571ACA', 'coucou', '0');
INSERT INTO `users` VALUES ('alemal@unamur.be', 'urF8ztNBHhFMOuQLszTCYQSyibNwEqpK', 'fred', 'al', '8CE4B16B22B58894AA86C421E8759DF3', 'frites', '0');
INSERT INTO `users` VALUES ('amelie.lemal@gmail.com', 'uArxf8l54ooDlbOeAQJm0TMsuctILFrS', 'Amélie ', 'Lemal', '347A11D1E4D12E53AC0B397425571ACA', 'Rue grandgagnage 26, Namur', '0');
INSERT INTO `users` VALUES ('hugues.marchal@mail.com', 'usssyS7I0aOnHUJ3oENQNQtI4NnVhV3Y', 'Hugues', 'Marchal', '6057F13C496ECF7FD777CEB9E79AE285', 'Rue grandgagnage 22, 5000 Namur', '0');
INSERT INTO `users` VALUES ('j', 'uD5QAVyutGsncTE3ol4tGHOQNZgGpBwY', 'j', 'j', '363B122C528F54DF4A0446B6BAB05515', 'j', '0');
INSERT INTO `users` VALUES ('marchal.hugues@outlook.com', 'uzohiDgjtjD20NmAcRRATIu1W3R6G3By', 'Hugues', 'Marchal', 'D719083F59856E34A37E2137E2241D80', 'Rue de Branchon 149', '0');
INSERT INTO `users` VALUES ('ranieri.osvaldo@skynet.be', 'u8Sbq5n3xiPOkR8Mer4lzWzMbgaC6wuH', 'fred', 'al', '8CE4B16B22B58894AA86C421E8759DF3', 'frites', '0');
INSERT INTO `users` VALUES ('zer@u.com', 'awkjd1o7AXL1m9cn9gXh3sXibW4Cxjyf', 'Zer', 'zer', '128ECF542A35AC5270A87DC740918404', 'zer', '1');
