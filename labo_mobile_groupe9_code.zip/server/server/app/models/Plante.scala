package models

/**
  * Created by Makarov on 24-04-17.
  */
class Plante (val name:String, val luminosite_min:Double, val luminosite_max:Double, val ph_min:Int, val ph_max:Int,
              val humidite_min:Double, val humidite_max:Double, val temperature_min:Double, val temperature_max:Double){

}

