package utils_project

import play.api.mvc.Request

/**
  * Created by Makarov on 26-04-17.
  */
object Sec {

  /**
    *
    * @param request la requête d'où est extraite la session.
    * @return true if logged in, false otherwise.
    */
  def isLogged(request:Request[Any]):Boolean = {
    request.session.get("connected").map { user =>
      return true
    }.getOrElse {
      //Unauthorized("Oops, you are not connected")
      return false
    }
  }

  /**
    *
    * @param request la requête d'où est extraite la session.
    * @return true if ADMIN logged in, false otherwise.
    */
  def isAdmin(request:Request[Any]):Boolean = {
    request.session.get("admin").map { user =>
      return true
    }.getOrElse {
      //Unauthorized("Oops, you are not connected")
      return false
    }
  }

  def getUserId(request: Request[Any]):String = {
    request.session.get("admin").map { user =>
      return user
    }.getOrElse {
      //Unauthorized("Oops, you are not connected")
      return ""
    }
  }


}
