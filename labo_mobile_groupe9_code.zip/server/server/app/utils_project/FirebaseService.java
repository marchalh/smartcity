package utils_project;

import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseCredentials;
import com.google.firebase.auth.internal.FirebaseTokenFactory;
import com.google.firebase.database.*;
import com.google.firebase.internal.FirebaseExecutors;
import org.json.JSONObject;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;

/**
 * Created by Makarov on 11-05-17.
 */
public class FirebaseService {

    public final static String AUTH_KEY_FCM = "AAAAStcbVi4:APA91bFylfoJy6R6tnTUGO_cv_B-MY-jEs67FsmlAyMgY6etz9uetpkOOLZ5iafmHpYi6OAT9Emee_xVXprnG1vQVy0H3hxFHQRT4qumtmC53Nx0gYgUgpj_mrct7GApxN85UMysjrzA";
    public final static String API_URL_FCM = "https://fcm.googleapis.com/fcm/send";

    private String PATH_TO_JSON = "C:\\Users\\Makarov\\Documents\\UNamur\\MA1\\Labo mobile\\server\\server\\server-43c9b-firebase-adminsdk-a22ew-e001c64985.json";
//    public void init(){
//        try {
//            FileInputStream serviceAccount = new FileInputStream(PATH_TO_JSON);
//
//            FirebaseOptions options = new FirebaseOptions.Builder()
//                    .setCredential(FirebaseCredentials.fromCertificate(serviceAccount))
//                    .setDatabaseUrl("https://server-43c9b.firebaseio.com")
//                    .setDatabaseAuthVariableOverride(null)
//                    .build();
//
//            FirebaseApp.initializeApp(options);
//            serviceAccount.close();
//            // As an admin, the app has access to read and write all data, regardless of Security Rules
//            DatabaseReference ref = FirebaseDatabase
//                    .getInstance()
//                    .getReference("restricted_access/secret_document");
//            ref.addListenerForSingleValueEvent(new ValueEventListener() {
//                @Override
//                public void onDataChange(DataSnapshot dataSnapshot) {
//                    Object document = dataSnapshot.getValue();
//                    System.out.println(document);
//                }
//
//                @Override
//                public void onCancelled(DatabaseError databaseError) {
//
//                }
//            });
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }


    public static void pushFCMNotification(String DeviceIdKey, JSONObject info) throws Exception {

        String authKey = AUTH_KEY_FCM; // You FCM AUTH key
        String FMCurl = API_URL_FCM;

        URL url = new URL(FMCurl);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setUseCaches(false);
        conn.setDoInput(true);
        conn.setDoOutput(true);

        conn.setRequestMethod("POST");
        conn.setRequestProperty("Authorization", "key=" + authKey);
        conn.setRequestProperty("Content-Type", "application/json");

        JSONObject data = new JSONObject();
        data.put("to", DeviceIdKey.trim());
        info.put("title", "FCM Notificatoin Title"); // Notification title
        info.put("body", "Hello First Test notification"); // Notification body
        data.put("data", info);

        OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
        wr.write(data.toString());
        wr.flush();
        wr.close();

        int responseCode = conn.getResponseCode();
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

    }


    public static void sendNotification(String notifTitle, String clientId, String body) throws IOException {
        final String apiKey = AUTH_KEY_FCM;
        URL url = new URL("https://fcm.googleapis.com/fcm/send");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setDoOutput(true);
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Authorization", "key=" + apiKey);

        conn.setDoOutput(true);

        String input = "{\"notification\" : {\"title\" : \""+notifTitle+"\", \"body\": \""+body+"\"}, \"to\":\""+ clientId+"\"}";

        OutputStream os = conn.getOutputStream();
        os.write(input.getBytes());
        os.flush();
        os.close();

        int responseCode = conn.getResponseCode();
        System.out.println("\nSending 'POST' request to URL : " + url);
        System.out.println("Post parameters : " + input);
        System.out.println("Response Code : " + responseCode);

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuffer response = new StringBuffer();

        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        // print result
        System.out.println(response.toString());
    }
}



