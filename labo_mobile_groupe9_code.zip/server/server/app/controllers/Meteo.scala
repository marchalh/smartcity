package controllers


import javax.inject.Inject

import play.api.Logger
import play.api.db.Database
import play.api.libs.json.{JsValue, Json}
import play.api.mvc._
/**
  * Created by Makarov on 24-04-17.
  */
class Meteo @Inject()(db: Database) extends Controller{

  /**
    * This method will set the new Meteo data inside the DB.
    *
    * @return
    */
  def setData() = Action { request =>
    Logger.info("Essai d'update des données météo arduino")
    val body: Option[String] = request.body.asText
    body match {
      case Some(x) => {
        Logger.info("Received : " + x)
        //String PARSER
        var counter:Int = 0
        var id:String = ""
        var temperature:String = ""
        var humidite:String = ""
        var soleil:String = ""
        x.map(c=>
          if (c == '/')
            {
              counter = counter + 1
              c
            }
          else
            counter match{
              case 0 => {
                id = id + c
                c
              }
              case 1 => {
                temperature = temperature + c
                c
              }
              case 2 => {
                humidite = humidite + c
                c
              }
              case 3 =>{
                soleil = soleil + c
                c
              }
            }
        )
        println("ID : "+id)
        println("TEMP : "+temperature)
        println("HUM : "+humidite)
        println("SOL : "+soleil)

        val conn = db.getConnection()
        val statement = conn.createStatement()
        val query = "INSERT INTO meteo (ensoleillement, temperature, id_station, humidite) VALUES ('" + soleil + "', '" +
          temperature + "', '" + id + "', '" + humidite + "') ON DUPLICATE KEY UPDATE ensoleillement=VALUES(ensoleillement), " +
          "temperature=VALUES(temperature), humidite=VALUES(humidite);"
        val res = statement.execute(query)
        if (!res) {
          Logger.info("Update done.")
          Ok("Données bien update")
        } else {
          Logger.info("Erreur interne. Abort.")
          InternalServerError("Une erreur est survenue lors de l'update")
        }
      }
      case None =>{
        Logger.info("BAD REQUEST. Abort")
        BadRequest("BAD REQUEST : Pas de données en paramètre.")
      }
    }

  }


  /**
    * This method will notify an admin that the sensor connection to the Arduino has been lost.
    * @return
    */
  def lost() = Action{request =>
    Logger.info("Signalement de la perte des sensors arduino.")
    utils_project.FirebaseService.sendNotification("New notif", "fbyrfbufrufeukf", "corps de la notification." )
    Ok("Le signelement a été effectué. //TODO")

  }

  def getMeteoData() = Action{request =>
    Logger.info("Demande des données météo globales.")
    val conn = db.getConnection()
    val statement = conn.createStatement()
    val query = "SELECT * FROM meteo;"
    val res = statement.executeQuery(query)
    var isEmpty = true
    var json:JsValue = null
    while(res.next()){
      isEmpty = false
      val s:String = """{ "ensoleillement" : "%d", "temperature" : "%d", "id_station" : "%s", "humidite" : "%d" }"""
      val str:String = s.format(res.getInt(1), res.getInt(2), res.getString(3), res.getInt(4))
      json = Json.parse(str)
    }
    if(isEmpty){
      Logger.info("Aucune donnée n'a pu être récupérée. Abort.")
      NotFound("Aucune donnée n'a pu être récupérée.")
    }else{
      Logger.info("Done.")
      Ok(json)
    }

  }

}
