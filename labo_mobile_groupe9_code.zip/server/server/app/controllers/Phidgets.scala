package controllers

import javax.inject.Inject

import play.api.Logger
import play.api.db.Database
import play.api.libs.json.{JsValue, Json}
import play.api.mvc.{Action, Controller}


import scala.util.parsing.json.JSONObject

/**
  * Created by Makarov on 26-04-17.
  */
class Phidgets @Inject()(db: Database) extends Controller{

  /**
    * This method will update the phidget data in the db when they are received and assert DO's from those values.
    * @param emplacement the name of the plant to update
    * @return ok if everything went fine, badrequest or internalError otherwise
    */
  def rpiSetPhidgetInfo(emplacement: String) = Action { request =>
    Logger.info("Essai d'update des données phidget pour l'emplacement : " + emplacement)
    emplacement match{
      case "" => BadRequest("Pas de nom en paramètre")
      case _ => {
        val conn = db.getConnection()
        try {
          val sender:String = request.remoteAddress
          //Getting data from JSON
          val jsonBody: Option[JsValue] = request.body.asJson
          jsonBody match{
            case Some (x) =>{
              Logger.info("BODY : "+x)
              val luminosite: Double = (x \"luminosite").as[String].toDouble
              val ph: Double = (x \"ph").as[String].toDouble
              val humidite: Double = (x \"humidite").as[String].toDouble
              val temperature: Double = (x \"temperature").as[String].toDouble
              //DB OPS
              //Getting the PLANTE_TYPE values
              val statement = conn.createStatement()
              val req = "SELECT * FROM plante_type WHERE nom=(SELECT nom FROM plante WHERE emplacement_id='"+emplacement+"');"
              val rs = statement.executeQuery(req)
              var isEmpty = true
              var res:Boolean = false
              var plante:models.Plante = null
              if(rs.next()){
                isEmpty = false
                plante = new models.Plante(rs.getString(1), rs.getDouble(2),rs.getDouble(3),
                  rs.getInt(4),rs.getInt(5),rs.getDouble(6),rs.getDouble(7),
                  rs.getDouble(8),rs.getDouble(9))
                //Working on the real PLANTE.
                val sql_req: String = "UPDATE plante SET luminosite='" + luminosite + "', ph='" + ph + "', humidite='" + humidite + "'," +
                  " temperature='" + temperature + "' WHERE emplacement_id='" + emplacement + "';"
                res = statement.execute(sql_req)
              }
              if(isEmpty){
                Logger.info("NOT FOUND. Abort.")
                NotFound("Impossible de trouver les valeurs d'une plante_type. Abort.")
              }
              else
                if (!res) {
                Logger.info("Done, renvoit des actions.")
                Ok(Json.parse(assertDOsFromValues(luminosite, ph, humidite, temperature, sender, plante)))
                } else {
                Logger.info("erreur. Abort.")
                NotFound("Une erreur s'est produite, l'update n'a pas eu lieu")
              }
            }
            case None =>{
              Logger.info("Abort, NO JSON in Body")
              BadRequest("Aucun élément JSON dans le body de la requête.")
            }
          }

        }
        catch {
          case e: Exception => {
            e.printStackTrace()
            InternalServerError("Erreur interne @"+this.getClass)
          }
        }
        finally conn.close()
      }
    }
  }


  /**
    * @param emplacement the name of the plante_type to retrieve from the table (plante_type).
    * @return (ok + JSON(phidget info)) if found, badrequest if not.
    */
  def getPhidgetInfo(emplacement: String) = Action { request =>
    Logger.info("Demande des dernières données phidget de la plante")
    var jsObject: JsValue = null
    val conn = db.getConnection()
    Logger.info("Emplacement : " + emplacement)
    try {
      val statement = conn.createStatement()
      val res = statement.executeQuery("SELECT nom, luminosite, ph, humidite, temperature FROM plante WHERE emplacement_id='" + emplacement + "';")
      var isEmpty: Boolean = true
      while (res.next()) {
        isEmpty = false
        val s: String =
          """{ "emplacement" : "%s", "nom" : "%s", "luminosite" : "%.3f", "ph" : "%.3f", "humidite" :
            | "%.3f", "temperature" : "%.3f" }""".stripMargin
        val str = s.format(emplacement, res.getString(1), res.getDouble(2), res.getDouble(3), res.getDouble(4), res.getDouble(5))
        jsObject = Json.parse(str)
      }
      if (isEmpty) {
        Logger.info("Not Found, Abort.")
        NotFound("Aucun résultat correspondant")
      }
      else {
        Logger.info("Done")
        Ok(jsObject)
      }
    }
    catch {
      case e: Exception => InternalServerError("Erreur interne @ " + this.getClass)
    }
    finally {
      conn.close()
    }
  }




  /**
    * Cette méthode traite la perte de connexion entre les phidgets et le raspberry. Dans le cas où l'emplacement
    * signalé n'est pas valide, NotFound est retourné, sinon Ok. Dans le dernir cas, l'administrateur responsable de
    * la serre (du TERRAIN) en sera notifié.
    * @return NotFound, Ok
    */
  def lostPhidget(emplacement:String) = Action{ request =>
    Logger.info("Signalement de la perte des connexions Phidget pour l'emplacement : "+emplacement)
    val conn = db.getConnection()
    val sender:String = request.remoteAddress
    try{
      val statement = conn.createStatement()
      val query = "SELECT * FROM emplacement WHERE id='"+emplacement+"';"
      val res = statement.executeQuery(query)
      if(!res.next()){
        Logger.info("NOT FOUND. Abort.")
        NotFound("Aucun emplacement correspondant n'a été trouvé.")
      }
      else{
        val responsable:String = res.getString("responsable")
        val req = "SELECT * FROM plante_type WHERE nom=(SELECT nom FROM plante WHERE emplacement_id='"+emplacement+"');"
        val rs = statement.executeQuery(req)
        var plante:models.Plante = null
        while(rs.next()){
          plante = new models.Plante(rs.getString(1), rs.getDouble(2),rs.getDouble(3),
            rs.getInt(4),rs.getInt(5),rs.getDouble(6),rs.getDouble(7),
            rs.getDouble(8),rs.getDouble(9))
        }
        //TODO NOTIFY ADMIN
        Logger.info("NOTIFY Admin, Sending Global meteo data. Done.")
        Ok(doFromMeteoData(sender, plante))
      }
    }catch {
      case e: Exception => InternalServerError("Erreur interne @"+this.getClass)
    }
    finally {
      conn.close()
    }
  }

  /**
    * This method will check and send to the sender of the data if those values are in the correct range. In any case,
    * a String telling the RPI what to do is gonna be returned.
    * @param lum the luminosity taken by sensors
    * @param ph the ph taken by sensors
    * @param hum the humidity taken by sensors
    * @param temp the temperature taken by sensors
    * @param sender the IP of the RPI that sent the data
    * @param plante the plante_type to which the data need to be compared.
    */
  private def assertDOsFromValues(lum:Double, ph:Double, hum:Double, temp:Double,
                                  sender:String, plante:models.Plante): String={
    var str:String = """{"""
    //Verifying LUMINOSITY
    if(lum<=plante.luminosite_min){
      str = str + """ "luminosite" : "plus" """
    }else if(lum>=plante.luminosite_max){
      str = str + """ "luminosite" : "moins" """
    }else
      str = str + """ "luminosite" : "ok" """

    //Verifying PH
    if(ph<=plante.ph_min){
      str = str + """, "ph" : "plus" """
    }else if(ph>=plante.ph_max){
      str = str + """, "ph" : "moins" """
    }else
      str = str + """, "ph" : "ok" """

    //Verifying HUMIDITY
    if(hum<=plante.humidite_min){
      str = str + """, "humidite" : "plus" """
    } else if(hum>=plante.humidite_max){
      str = str + """, "humidite" : "moins" """
    }else
      str = str + """, "humidite" : "ok" """

    //Verifying TEMPERATURE
    if(temp<=plante.temperature_min){
      str = str + """, "temperature" : "plus" }"""
    }else if(temp>=plante.temperature_max){
      str = str + """, "temperature" : "moins" }"""
    }else
      str = str + """, "temperature" : "ok" }"""
    Logger.info("MESSAGE : "+str)
    str
  }

  private def doFromMeteoData(sender:String, plante:models.Plante): JsValue ={
    Logger.info("Demande des données météo globales.")
    val conn = db.getConnection()
    val statement = conn.createStatement()
    val query = "SELECT * FROM meteo;"
    val res = statement.executeQuery(query)
    var isEmpty = true
    var string:String = null
    var str:String = """{"""
    while(res.next()){
      isEmpty = false
      val s:String = """{ "ensoleillement" : "%d", "temperature" : "%d", "id_station" : "%s", "humidite" : "%d" }"""
      string = s.format(res.getInt(1), res.getInt(2), res.getString(3), res.getInt(4))
      val lum = res.getInt(1)
      val temp = res.getInt(2)
      val hum = res.getInt(4)
      //Verifying LUMINOSITY
      if(lum<=plante.luminosite_min){
        str += """ "luminosite" : "plus""""
      }else if(lum>=plante.luminosite_max){
        str += """ "luminosite" : "moins""""
      }else
        str += """ "luminosite" : "ok""""


      str += """, "ph" : "ok""""

      //Verifying HUMIDITY
      if(hum<=plante.humidite_min){
        str += """, "humidite" : "plus""""
      } else if(hum>=plante.humidite_max){
        str += """, "humidite" : "moins""""
      }else
        str += """, "humidite" : "ok""""

      //Verifying TEMPERATURE
      if(temp<=plante.temperature_min){
        str += """, "temperature" : "plus" """
      }else if(temp>=plante.temperature_max){
        str += """, "temperature" : "moins" """
      }else
        str += """, "temperature" : "ok""""
    }
    str+= "}"
    if(isEmpty){
      Logger.info("Aucune donnée n'a pu être récupérée, return null")
      Json.parse(str)
    }else{
      Logger.info("Done.")
      Json.parse(str)
    }
  }


  private def getMeteoData():String = {
    Logger.info("Demande des données météo globales.")
    val conn = db.getConnection()
    val statement = conn.createStatement()
    val query = "SELECT * FROM meteo;"
    val res = statement.executeQuery(query)
    var isEmpty = true
    var str:String = null
    while(res.next()){
      isEmpty = false
      val s:String = """{ "ensoleillement" : "%d", "temperature" : "%d", "id_station" : "%s", "humidite" : "%d" }"""
      str = s.format(res.getInt(1), res.getInt(2), res.getString(3), res.getInt(4))
    }
    if(isEmpty){
      Logger.info("Aucune donnée n'a pu être récupérée, return null")
      str
    }else{
      Logger.info("Done.")
      str
    }

  }

}
