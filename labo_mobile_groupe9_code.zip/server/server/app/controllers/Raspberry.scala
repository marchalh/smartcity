package controllers

import javax.inject.Inject

import play.api.Logger
import play.api.db.{Database, NamedDatabase}
import play.api.libs.json.{JsValue, Json}
import play.api.mvc.{Action, Controller}

import scala.collection.mutable

/**
  * Created by Makarov on 04-05-17.
  */
class Raspberry @Inject()(db: Database) extends Controller{


  /**
    * Cette méthode va aller chercher en DB les ID des emplacements liés au RPI qui demande (identifié via son IP - même
    * dans la DB) ainsi que si l'emplacement est libre et s'il est accessible, le tout au format JSON.
    * NOTER FORMAT DU JSON renvoyé : "{emplacements : [{id, free, access_user}, ...]}
    * @return Ok(JSON) si la demande a abouti, BadRequest si rien n'a été trouvé en DB, InternalServerError si une
    *         Exception a été levée.
    */
  def demandeEmplacements() = Action { request =>
    val rpiId:String = request.remoteAddress
    Logger.info("Demande des emplacements à gérer par le RPI : "+rpiId)
    val conn = db.getConnection()
    try{
      //Setting request and access to get the list.
      val query = "SELECT id, free, access_user FROM emplacement WHERE raspberry_id='"+rpiId+"';"
      val statement = conn.createStatement()
      val res = statement.executeQuery(query)
      var isEmpty = true
      //Putting retrieved data to JSON.
      var list:mutable.MutableList[String] = new mutable.MutableList[String]
      while(res.next()){
        isEmpty = false
        val s:String = """{ "id" : "%s", "free" : "%d", "access_user" : "%d" }"""
        val str = s.format(res.getString(1), res.getInt(2), res.getInt(3))
        list.+=(str)
      }
      //Si des valeurs ont été trouvée
      if(!isEmpty){
        var toParse:String = """{ "emplacements" : ["""
        list.foreach(x =>
          if(x!=list.last)
            toParse = toParse + x + ", "
          else
            toParse = toParse + x + "]}")
        Logger.info("Done.")
        Ok(Json.parse(toParse))
      //Si aucune valeur n'a été trouvée
      }else{
        Logger.info("NOT FOUND : Abort.")
        NotFound("Le serveur n'a pas pu récupérer d'emplacements pour l'id du RPI concerné.")
      }
    }catch {
      case e: Exception => {
        e.printStackTrace()
        InternalServerError("Erreur interne @"+this.getClass)
      }
    }
    finally conn.close()
  }

  /**
    * Cette méthode va modifier l'accessibilité à un terrain (identifié par l'id du RPI) en fonction du paramètre reçu.
    * @param acces l'accessibilité du terrain : 0 = inaccessible, 1 = accessible.
    * @return Ok(message) si l'update a bien été effectuée, BadRequest si elle n'a pas eu lieu, et InternalServerError
    *         si une Exception a été lancée.
    */
  def accessibilite(acces: Int) = Action { request =>
    val rpiId: String = request.remoteAddress
    Logger.info("Modification de l'accessibilité d'un terrain à : " + acces)
    val conn = db.getConnection()
    try {
      //Setting request and access to get the list.
      val s = "UPDATE emplacement SET access_user='%d' WHERE raspberry_id='%s';"
      val query = s.format(acces,rpiId)
      val statement = conn.createStatement()
      val res = statement.execute(query)
      if (res) {
        Logger.info("Done.")
        Ok("La table a bien été mise à jour.")
      }
      else {
        Logger.info("NOT FOUND : Abort.")
        NotFound("La mise à jour n'a pas été effectuée.")
      }
    } catch {
      case e: Exception => {
        e.printStackTrace()
        InternalServerError("Erreur interne @"+this.getClass)
      }
    }
    finally conn.close()
  }


  /**
    * Cette méthode va renvoyer la liste complète d'utilisateurs présents dans la DB, en renvoyant les valeurs : rfid et
    * admin.
    * NOTER LE FORMAT JSON : {utilisateurs : [{rfid_tag_nbr, admin},...]}
    * @return Ok(json) la requête a bien été effectuée, BadRequest(message) si aucun utilisateur n'a été trouvé et
    *         InternalServerError(message) si une Exception a été levée.
    */
  def listerUtilisateurs() = Action{request =>
    val rpiId:String = request.remoteAddress
    Logger.info("Demande de la liste d'utilisateurs (de leurs rfid - admin status) pour "+rpiId)
    val conn = db.getConnection()
    try{
      val statement = conn.createStatement()
      val s:String = "SELECT DISTINCT raspberry_id FROM emplacement WHERE raspberry_id='%s';"
      val query_verif = s.format(rpiId)
      val query_users = "SELECT rfid_tag_nbr, admin FROM users;"
      val rs = statement.executeQuery(query_verif)
      if(rs.next()){
        val res = statement.executeQuery(query_users)
        var isEmpty = true
        //Putting retrieved data to JSON.
        var list:mutable.MutableList[String] = new mutable.MutableList[String]
        while(res.next()){
          isEmpty = false
          val s:String = """{ "rfid_tag_nbr" : "%s", "admin" : "%d" }"""
          val str = s.format(res.getString(1), res.getInt(2))
          list.+=(str)
        }
        //Si des valeurs ont été trouvée
        if(!isEmpty){
          var toParse:String = """{ "utilisateurs" : [ """
          list.foreach(x =>
            if(x!=list.last)
              toParse = toParse + x + ", "
            else
              toParse = toParse + x + "]}")
          Logger.info("Done.")
          Ok(Json.parse(toParse))
          //Si aucune valeur n'a été trouvée
        }else{
          Logger.info("NOT FOUND : Abort.")
          NotFound("Le serveur n'a pas pu récupérer la liste des utilisateurs")
        }
      }
      else{
        Logger.info("No RPI_id match, Abort.")
        NotFound("Le rpi d'origine est inconnu.")
      }
    }catch {
      case e: Exception => {
        e.printStackTrace()
        InternalServerError("Erreur interne @"+this.getClass)
      }
    }
    finally conn.close()
  }


  def ajouterEmplacement() = Action{request =>
    Logger.info("Tentative d'ajout d'un emplacement par un admin.")
    if(utils_project.Sec.isAdmin(request)){
      request.body.asJson match{
        case Some(x) => {
          val lat: Double = (x \"lat").as[Double]
          val longitude:Double = (x \"longitude").as[Double]
          val raspberry:String = (x \"raspberry_id").as[String]
          val free:Int = 1
          val access_user:Int = 1
          val responsable:String = utils_project.Sec.getUserId(request)
          if(responsable == ""){
            Logger.info("NOT FOUND, No Responsable. Abort.")
            NotFound("Le responsable n'a pas été trouvé.")
          }else{
            val conn = db.getConnection()
            try{
              val id:String = raspberry + makeEmplacementId()
              val s = "INSERT INTO emplacement VALUES('%s', '%f', '%f', '%s', '%d', '%d', '%s');"
              val query = s.format(id,lat,longitude,raspberry,free,access_user,responsable)
              val statement = conn.createStatement()
              val res = statement.execute(query)
              if(res){
                Logger.info("Done.")
                Ok("Done.")
              }else
                Logger.info("ERROR, Abort.")
              InternalServerError("Une erreur est survenue pendant l'ajout.")
            }catch {
              case e: Exception => {
                e.printStackTrace()
                InternalServerError("Erreur interne @"+this.getClass)
              }
            }
            finally conn.close()
          }
        }
        case None => {
          Logger.info("BAD REQUEST, NO JSON. Abort.")
          BadRequest("No JSON in body")
        }
      }
    }else{
      Logger.info("UNAUTHORIZED : Abort.")
      Unauthorized("L'utilisateur ne dispose pas des droits administrateur.")
    }
  }


  def removeEmplacement(emplacement:String) = Action { request =>
    Logger.info("Tentative de suppression d'emplacement par un admin (cascade, de plante).")
    if(utils_project.Sec.isAdmin(request)){
      val conn = db.getConnection()
      try{
        val statement = conn.createStatement()
        val query_plante :String = "DELETE FROM plante WHERE emplacement_id='"+emplacement+"';"
        val query_empl : String = "DELETE FROM emplacement WHERE id='"+emplacement+"';"
        val rs = statement.execute(query_plante)
        val res = statement.execute(query_empl)
        if(res && rs){
          Logger.info("Done.")
          Ok("Done.")
        }else{
          Logger.info("NOT FOUND, Abort.")
          NotFound("Aucun emplacement correspondant n'a été trouvé ou n'a pu être supprimé.")
        }
      }catch {
        case e: Exception => {
          e.printStackTrace()
          InternalServerError("Erreur interne @"+this.getClass)
        }
      }
      finally conn.close()
    }else{
      Logger.info("UNAUTHORIZED : ABort.")
      Unauthorized("L'utilisateur ne dispose pas des droits administrateur.")
    }
  }


  private def makeEmplacementId():String={
    checkTag(makeString())
  }


  private def makeString():String={
    val length:Int = 4
    val chars = ('a' to 'z') ++ ('A' to 'Z') ++ ('0' to '9')
    //Treatment
    val sb = new StringBuilder
    for (i <- 1 to length) {
      val randomNum = util.Random.nextInt(chars.length)
      sb.append(chars(randomNum))
    }
    sb.toString
  }

  /**
    *
    * @param tag the String tag to check the unicity of (check via db, users table).
    * @return
    */
  private def checkTag(tag:String):String = {
    val conn = db.getConnection()
    try{
      val statement = conn.createStatement()
      val query = "SELECT id FROM emplacement where id='"+tag+"';"
      val res = statement.executeQuery(query)
      var counter = true
      while(res.next()){
        counter = false
      }
      if (counter) {
        tag
      } else {
        makeEmplacementId()
      }
    }
    catch{
      case e:Exception =>{
        Logger.info("Une erreur interne est survenue lors du check du rfid, trying again")
        makeEmplacementId()
      }
    }
    finally{
      conn.close()
    }
  }
}
