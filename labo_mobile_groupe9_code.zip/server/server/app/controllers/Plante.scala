package controllers


import java.text.{DateFormat, SimpleDateFormat}
import javax.inject.Inject

import org.joda.time.{DateTime, Days}
import play.api.Logger
import play.api.db.Database
import play.api.libs.json.{JsValue, Json}
import play.api.mvc._
import utils_project.Sec

import scala.collection.mutable
import scala.util.{Failure, Success, Try}

/**
  * Created by Makarov on 08-04-17.
  */
class Plante @Inject()(db: Database) extends Controller{

  def getAllPlanteType() = Action {request =>
    Logger.info("Demande des caractéristiques de toutes les plantes_types : ")
    var jsObject: JsValue = null
    val conn = db.getConnection()
    try {
      val statement = conn.createStatement()
      val res = statement.executeQuery("SELECT * FROM plante_type;")
      var list:mutable.MutableList[String] = new mutable.MutableList[String]
      var isEmpty: Boolean = true
      while (res.next()) {
        isEmpty = false
        val s = """{ "nom" : "%s", "luminosite_min" : "%d", "luminosite_max" : "%d",""" +
          """ "ph_min" : "%d", "ph_max" : "%d", "humidite_min" : "%d", "humidite_max" : "%d",""" +
                """ "temperature_min" : "%d", "temperature_max" : "%d", "date_plantation_debut" : "%s", "date_plantation_fin" : "%s", """ +
          """"date_recolte_debut" : "%s", "date_recolte_fin" : "%s", "temps_maturite" : "%d" }"""
        val str = s.format(res.getString(1), res.getInt(2), res.getInt(3), res.getInt(4), res.getInt(5),
          res.getInt(6), res.getInt(7), res.getInt(8), res.getInt(9), res.getString(11), res.getString(12), res.getString(13), res.getString(14), res.getInt(15))
        list.+=(str)

      }
      if (!isEmpty){
        var toParse:String = """["""
        list.foreach(x =>
          if(x!=list.last)
            toParse = toParse + x + ", "
          else
            toParse = toParse + x + "]")
        Logger.info("DATA : "+toParse)
        Logger.info("Done.")
        Ok(Json.parse(toParse))
      }
      else{
        Logger.info("NOT FOUND, Abort.")
        NotFound("Aucune plante_type n'a été trouvée.")
      }
    }
    catch {
      case e: Exception =>{
        e.printStackTrace()
        InternalServerError("Erreur interne @"+this.getClass)
      }
    }
    finally {
      conn.close()
    }
  }

  def getPlanteAndEmplacementInfo() = Action {request=>
    Logger.info("Demande de récupération des infos des plantes et des emplacements libres dans la même requête.")
    db.withConnection{ conn =>
      try {
        val statement = conn.createStatement()
        var query_plante:String = "SELECT nom, emplacement_id, date_recolte_calculee FROM plante;"
        var list:mutable.MutableList[String] = new mutable.MutableList[String]
        var l:mutable.MutableList[String] = new mutable.MutableList[String]
        var ok: Boolean = false
        val rs = statement.executeQuery(query_plante)
        while(rs.next()) {
          ok = true
          val s = """{ "nom" : "%s", "emplacement_id" : "%s""""
          val string = getEmplacementListe(rs.getString(2))
          val str = s+string
          list.+=(str.format(rs.getString(1), rs.getString(2)))
        }
        if(ok) {
          var toParse:String = """[ """
          list.foreach(x =>
            if(x!=list.last)
              toParse = toParse + x + ", "
            else
              toParse = toParse + x + "]")
          Logger.info("DATA : "+toParse)
          Logger.info("Done")
          Ok(Json.parse(toParse))
        } else {
          Logger.info("NOT FOUND, Abort.")
          NotFound("Aucune donnée n'a pu être récupérée")
        }
      }
      catch {
        case e: Exception => {
          e.printStackTrace()
          InternalServerError("Erreur interne @ "+this.getClass)
        }
      }
      finally {
        conn.close()
      }
    }
  }


  /**
    * @return la liste complète de plantes à récolter(plantées, pas de plante_type) en db sous forme de requête contenant un
    *         JsArray, si pas en db, renvoit InternalServerError.
    */
  def listPlantes() = Action { request =>
    Logger.info("Getting the list of all plants")
    db.withConnection{ conn =>
      try {
        val statement = conn.createStatement()
        var query_plante:String = "SELECT nom, emplacement_id FROM plante WHERE plante.a_recolter='1';"
        var list:mutable.MutableList[JsValue] = new mutable.MutableList[JsValue]
        var ok: Boolean = false
        val rs = statement.executeQuery(query_plante)
        while(rs.next()){
          ok = true
          val s = """{ "nom" : "%s", "emplacement_id" : "%s" }"""
          val str = s.format(rs.getString(1), rs.getString(2))
          list.+=(Json.parse(str))
        }
        if(ok) {
          var toParse:String = """[ """
          list.foreach(x =>
            if(x!=list.last)
              toParse = toParse + Json.stringify(x) + ", "
            else
              toParse = toParse + Json.stringify(x) + "]")
          Logger.info("TO SEND : "+toParse)
          Logger.info("Done")
          Ok(Json.parse(toParse))
        } else {
          Logger.info("NOT FOUND, Abort.")
          NotFound("Aucune donnée n'a pu être récupérée")
        }
      }
      catch {
        case e: Exception => {
          e.printStackTrace()
          InternalServerError("Erreur interne @ "+this.getClass)
        }
      }
      finally {
        conn.close()
      }
    }
  }


  /**
    * @param name the name of the plante_type to retrieve from the table (plante_type).
    * @return (ok + JSON(all plant info)) if found, badrequest if not.
    */
  def getPlantInfo(name: String) = Action { request =>
    Logger.info("Demande des caractéristiques de la plante : " + name)
    var jsObject: JsValue = null
    val conn = db.getConnection()
    try {
      val statement = conn.createStatement()
      val res = statement.executeQuery("SELECT * FROM plante_type WHERE nom='" + name + "';")
      var isEmpty: Boolean = true
      while (res.next()) {
        isEmpty = false
        val s = """{ "nom" : "%s", "luminosite_min" : "%d", "luminosite_max" : "%d",""" +
            """ "ph_min" : "%d", "ph_max" : "%d", "humidite_min" : "%d", "humidite_max" : "%d",""" +
            """ "temperature_min" : "%d", "temperature_max" : "%d", "temps_maturite" : "%d" }"""
        val str = s.format(res.getString(1), res.getInt(2), res.getInt(3), res.getInt(4), res.getInt(5),
          res.getInt(6), res.getInt(7), res.getInt(8), res.getInt(9), res.getInt(13))
        jsObject = Json.parse(str)
      }
      if (!isEmpty){
        Logger.info("DATA : "+jsObject.as[String])
        Logger.info("Done.")
        Ok(jsObject)
      }
      else{
        Logger.info("NOT FOUND, Abort.")
        NotFound("Aucune plante correspondante n'a été trouvée.")
      }
    }
    catch {
      case e: Exception =>{
        e.printStackTrace()
        InternalServerError("Erreur interne @"+this.getClass)
      }
    }
    finally {
      conn.close()
    }
  }


  /**
    *
    * @param user_rfid l'utilisateur ayant ajouté la plante (son rfid).
    * @return
    */
  def ajoutPlante(user_rfid: String) = Action { request =>
    Logger.info("Ajout de la plante plantée par l'utilisateur dans les db")
    if (Sec.isLogged(request)) {
      val conn = db.getConnection()
      try {
        val jsBody: Option[JsValue] = request.body.asJson
        jsBody match {
          case Some(x) => {
            val json: JsValue = jsBody.get
                //Parsing JSON
                //plante info
                val statement = conn.createStatement()
                val name: String = (json \ "nom").as[String]
                val date_plantation: String = (json \ "date_plantation").as[String]
                //Emplacement
                val id: String = (json \ "emplacement_id").as[String]
                //Calculating values
                val date_recolte_cal: String = calculateDateRecolte(date_plantation, name)
                //Setting DB connection
                val s: String = "INSERT INTO plante (nom, date_plantation, user_rfid, date_recolte_calculee, a_recolter, emplacement_id)" +
                  "VALUES ('%s', '%s', '%s', '%s', '0', '%s');"
                val query = s.format(name, date_plantation, user_rfid, date_recolte_cal, id)
                val query_emplacement = "UPDATE emplacement SET free='0' WHERE id='" + id + "';"
                val res = statement.execute(query)
                val rs = statement.execute(query_emplacement)
                if (!(res && rs)) {
                  Logger.info("Done.")
                  Ok("La plante a bien été ajoutée.")
                }
                else {
                  Logger.info("NOT UPDATED, Abort.")
                  NotFound("La demande n'a pas abouti.")
                }

            }


          case None => {
            Logger.info("BAD REQUEST, Abort.")
            BadRequest("Pas d'élément à ajouter dans le corps de la requête.")
          }
        }
      }
      catch {
        case e: Exception => {
          e.printStackTrace()
          InternalServerError("Erreur interne @ Plante.setPhidgetInfo")
        }
      }
      finally conn.close()
    } else {
      Logger.info("Unauthorized access.")
      Unauthorized("L'utilisateur n'est pas authentifié")
    }
  }



  /**
    * Cette fonction permet de réserver une plante pour l'utilisateur qui l'a plantée.
    * @param user_rfid l'utilisateur demandant la réservation.
    * @return Unauthorized
    */
  def reserver(user_rfid:String) = Action{request =>
    if (Sec.isLogged(request)) {
      val conn = db.getConnection()
      try {
        val statement = conn.createStatement()
        //Getting content from JSON
        request.body.asJson match {
          case Some(x) => {
                //Parsing JSON
            Logger.info("JSBODY : "+x)
            Logger.info("USER_RFID : "+user_rfid)
                val emplacement = (x \ "emplacement").as[String]
                val plante_name = (x \ "plante_name").as[String]
                val format = new java.text.SimpleDateFormat("yyyy-MM-dd")
                val date: String = format.format(new java.util.Date())
                val query_rfid = "SELECT user_rfid FROM plante WHERE user_rfid='" + user_rfid + "';"
                val res = statement.executeQuery(query_rfid)
                var isEmpty:Boolean = true
                var rs:Boolean = false
                if(res.next()){
                  isEmpty = false
                  val usr_rfid: String = res.getString(1)
                  if(usr_rfid==user_rfid) {
                    val query: String = "INSERT INTO reservation (user_id, plante_name, date_reservation, emplacement_id) " +
                      "VALUES ('" + user_rfid + "', '" + plante_name + "', '" + date + "', '" + emplacement + "')" +
                      " ON DUPLICATE KEY UPDATE user_id=VALUES(user_id), plante_name=VALUES(plante_name), " +
                      "date_reservation=VALUES(date_reservation);"
                    rs = statement.execute(query)
                  }else{
                    BadRequest("La vérification n'a pas pu être faite")
                  }
                }
                if (isEmpty){
                  Logger.info("NOT FOUND. Abort.")
                  NotFound("L'utilisateur n'a pas pu être trouvé.")
                }
                else
                if (!rs) {
                  Logger.info("done.")
                  Ok("Réservation effectuée")
                } else {
                  Logger.info("FAILED. Abort.")
                  InternalServerError("La réservation n'a pas pu être effectuée suite à une erreur interne. Insert failed")
                }
              }

          case None => {
            Logger.info("BAD REQUEST, Abort.")
            BadRequest("Pas de données dans le corps de la requête.")
          }
        }
      }
      catch {
        case e: Exception => {
          e.printStackTrace()
          InternalServerError("Erreur interne @"+this.getClass)
        }
      }
      finally conn.close()
    } else {
      Unauthorized("L'utilisateur n'est pas authentifié")
    }
  }

  def listerPlantesReservees(user_rfid:String) = Action {request =>
    Logger.info("Demande d'une liste de plantes réservées par l'utilisateur : "+user_rfid)
    val conn = db.getConnection()
    try{
      val query:String = "SELECT emplacement_id FROM reservation WHERE user_id='"+user_rfid+"';"
      val statement = conn.createStatement()
      val res = statement.executeQuery(query)
      var list: mutable.MutableList[String] = new mutable.MutableList[String]
      var isEmpty: Boolean = true
      while(res.next()){
        isEmpty = false
        list.+= (res.getString(1))
      }
      if(isEmpty){
        Logger.info("NOT FOUND. Abort")
        NotFound("Error, abort.")
      }else{
        var toParse:String = """[ """
        var l: mutable.MutableList[JsValue] = new mutable.MutableList[JsValue]
        list.foreach(x =>{
          val query = "SELECT nom, a_recolter, date_recolte_calculee FROM plante WHERE emplacement_id='"+x+"';"
          val rs = statement.executeQuery(query)
          var isEmpty = true
          val now = DateTime.now
          while(rs.next()){
            isEmpty = false
            val date_calc:DateTime = stringToDate(rs.getString(3))
            val remaining = Days.daysBetween(date_calc, now).getDays
            val s:String = """{ "name" : "%s", "id_emplacement" : "%s", "pret" : "%d", "remaining" : "%d" }"""
            val str = s.format(rs.getString(1), x, rs.getInt(2), remaining)
            l.+=(Json.parse(str))
          }
        })
        l.foreach(x=> {
          if(x!=l.last)
            toParse = toParse + Json.stringify(x) + ", "
          else
            toParse = toParse + Json.stringify(x) + "]"
        })

        Logger.info("Done")
        Ok(Json.parse(toParse))
      }

    }catch {
      case e: Exception => {
        e.printStackTrace()
        InternalServerError("Erreur interne @"+this.getClass)
      }
    }
    finally conn.close()
  }

  def resilierReservation(user_rfid:String) = Action { request =>
    Logger.info("Demande de résiliation d'une réservation de plante.")
    if (Sec.isLogged(request)) {
      request.body.asJson match {
        case Some(x) => {
          val conn = db.getConnection()
          try {
            Logger.info("USER_RFID : " + user_rfid)
            val nom: String = (x \ "nom").as[String]
            Logger.info("NOM : " + nom)
            val query: String = "DELETE FROM reservation WHERE user_id='" + user_rfid + "' AND plante_name='" + nom + "';"
            val statement = conn.createStatement()
            val res = statement.execute(query)
            if (!res) {
              Logger.info("Done.")
              Ok("Réservation supprimée.")
            } else {
              Logger.info("ERROR. Abort")
              InternalServerError("Error, abort.")
            }
          } catch {
            case e: Exception => {
              e.printStackTrace()
              InternalServerError("Erreur interne @" + this.getClass)
            }
          }
          finally conn.close()
        }
        case None => {
          Logger.info("BAD REQUEST : Abort.")
          BadRequest("Pas de JSON trouvé.")
        }
      }
    }
    else {
      Logger.info("UNAUTHORIZED. Abort.")
      Unauthorized("L'utilisateur n'est pas connecté.")
    }
  }




  /**
    * This method sets the plant (identified by the name given) to 'harvested' via a boolean.
    *
    * @param emplacement the id of the emplacement to be set as recolted.
    * @return ok, otherwise BadRequest or InternalError.
    */
  def setRecoltee(emplacement: String) = Action { request =>
    Logger.info("Set plante à l'emplacement : " + emplacement + " est récoltée en ENTIER")
    if (Sec.isLogged(request)) {
      emplacement match {
        case "" => BadRequest("Pas d'emplacement en paramètre")
        case _ => {
          val conn = db.getConnection()
          try {
            val statement = conn.createStatement()
            val sql_req: String = "DELETE FROM plante WHERE emplacement_id='" + emplacement + "';"
            val s:String = "UPDATE emplacement SET free='1' WHERE id='"+emplacement+"';"
            val res = statement.execute(sql_req)
            val rs = statement.execute(s)
            if (!(res && rs)) {
              Logger.info("Done.")
              Ok("Done updating")
            } else {
              Logger.info("ERROR, Abort.")
              InternalServerError("Une erreur s'est produite, l'update n'a pas eu lieu")
            }
          }
          catch {
            case e: Exception => {
              e.printStackTrace()
              InternalServerError("Erreur interne @"+this.getClass)
            }
          }
          finally conn.close()
        }
      }
    } else {
      Unauthorized("L'utilisateur n'est pas authentifié")
    }
  }



  def setARecolter(emplacement: String) = Action { request =>
    Logger.info("Changement de statut de la plante : " + emplacement + " vers 'a_recolter = true'")
    if (Sec.isAdmin(request)) {
      val conn = db.getConnection()
      try {
        val statement = conn.createStatement()
        val sql_req: String = "UPDATE plante SET a_recolter='1' WHERE emplacement_id='" + emplacement + "';"
        val res = statement.execute(sql_req)
        if (!res) {
          Logger.info("Done.")
          Ok("Done updating")
        } else {
          Logger.info("NOT FOUND, Abort.")
          NotFound("Une erreur s'est produite, l'update n'a pas eu lieu")
        }
      }
      catch {
        case e: Exception => {
          e.printStackTrace()
          InternalServerError("Erreur interne @" + this.getClass)
        }
      }
      finally conn.close()
    } else {
      Unauthorized("Il est nécessaire d'être administrateur et authentifié")
    }
  }


  def listerPlantesSupposePretes() = Action { request =>
    Logger.info("Demande de la liste des plantes prêtes.")
    if(Sec.isAdmin(request)){
      val conn = db.getConnection()
      try{
        val statement = conn.createStatement()
        val query = "SELECT nom, emplacement_id, date_recolte_calculee FROM plante WHERE a_recolter='0';"
        val res = statement.executeQuery(query)
        var list: mutable.MutableList[String] = new mutable.MutableList[String]
        val now:DateTime = DateTime.now()
        var isEmpty = true
        while(res.next()){
          isEmpty = false
          Logger.info("DATE (to convert) : "+res.getString(3))
          Logger.info("DATE (CONVERSION) : "+stringToDate(res.getString(3)))
          Logger.info("IS AFTER : " +isDatetimeAfterDate(now, stringToDate(res.getString(3))) )
          if(isDatetimeAfterDate(stringToDate(res.getString(3)), now)){
            Logger.info("IS AFTER : " +isDatetimeAfterDate(stringToDate(res.getString(3)), now) )
            val s:String = """{ "name" : "%s", "id_emplacement" : "%s" }"""
            list.+=(s.format(res.getString(1), res.getString(2)))
          }
        }
        if(isEmpty){
          Logger.info("NOT FOUND, Abort")
          NotFound("Aucun élément trouvé.")
        }else{
          var toParse:String = """[ """
          if(list.nonEmpty)
            list.foreach(x=>
              if(x!=list.last)
                toParse = toParse + x + ", "
              else
                toParse = toParse + x + "]")
          else
            toParse = toParse + "]"
          Logger.info("Done : "+ toParse)
          Ok(Json.parse(toParse))
        }
      }catch {
        case e: Exception => {
          e.printStackTrace()
          InternalServerError("Erreur interne @" + this.getClass)
        }
      }
      finally conn.close()
    }else{
      Logger.info("UNAUTHORIZED, Abort.")
      Unauthorized("L'utilisateur n'est pas admin.")
    }
  }


  /**
    *
    * @return Ok avec la liste d'emplacements libres, ou InternalServerError si quelque chose s'est mal passé.
    */
  def freeEmplacementListe() = Action {request =>
    Logger.info("Demande de liste d'emplacements libres.")
    val conn = db.getConnection()
    try{
      val statement = conn.createStatement()
      val query = "SELECT id, lat, longitude, raspberry_id FROM emplacement WHERE free='1';"
      val res = statement.executeQuery(query)
      var list:mutable.MutableList[String] = new mutable.MutableList[String]
      var isEmpty = true
      while(res.next()){
        isEmpty = false
        val s : String = """{ "id" : "%s", "lat" : "%f", "longitude" : "%f", "raspberry_id" : "%s" }"""
        val str = s.format(res.getString(1), res.getFloat(2), res.getFloat(3), res.getString(4))
        list.+=(str)
      }
      //Si des valeurs ont été trouvée
      if(!isEmpty){
        var toParse:String = """["""
          list.foreach(x =>
            if(x!=list.last)
              toParse = toParse + x + ", "
            else
              toParse = toParse + x + "]")
        Logger.info("DATA : "+toParse)
        Logger.info("Done.")
        Ok(Json.parse(toParse))
        //Si aucune valeur n'a été trouvée
      }else{
        Logger.info("NOT FOUND : Abort.")
        NotFound("Le serveur n'a pas pu récupérer la liste d'emplacements libres.")
      }
    }
    catch {
      case e:Exception => {
        e.printStackTrace()
        Logger.info("ERROR, Abort.")
        InternalServerError("Erreur interne @"+this.getClass)
      }
    }
    finally conn.close()
  }


  def listerPlantesMalades() = Action { request =>
    Logger.info("Demande de la liste des plantes malades avec emplacements.")
    val conn = db.getConnection()
    try{
      val statement = conn.createStatement()
      val query = "SELECT plante.nom, plante.emplacement_id FROM plante, plante_type WHERE plante.nom = plante_type.nom AND " +
        "(plante_type.ph_min > plante.ph OR plante_type.ph_max < plante.ph);"
      val res = statement.executeQuery(query)
      var isEmpty = true
      var list:mutable.MutableList[String] = new mutable.MutableList[String]
      while(res.next()){
        isEmpty = false
        val s:String = """{ "name" : "%s", "id_emplacement" : "%s" }"""
        list.+=(s.format(res.getString(1), res.getString(2)))
      }
      if(isEmpty){
        Logger.info("NOT FOUND, Abort.")
        NotFound("Pas de plante correspondante.")
      }else{
        var toParse:String = """[ """
        list.foreach(x =>
          if(x!=list.last)
            toParse = toParse + x + ", "
          else
            toParse = toParse + x + "]")
        Logger.info("Done")
        Ok(Json.parse(toParse))
      }
    }catch {
      case e:Exception => {
        e.printStackTrace()
        Logger.info("ERROR, Abort.")
        InternalServerError("Erreur interne @"+this.getClass)
      }
    }
    finally conn.close()
  }




  /**
    * Récupère la valeur du champ 'id' dans la requête 'content'
    */
  private def getValueFromRequest(content:AnyContent, id:String) = {
    Try(content.asFormUrlEncoded.get(id)(0)) match {
      case Success(x) => Some(x)
      case Failure(x) => None
    }
  }


  /**
    * Cette méthode va calculer la date de récolte a priori de la plante, grâce au temps de maturité de la plante_type
    * (en jours).
    * @param date_plant la date de plantaison.
    * @return la date de récolte calculée.
    */
  private def calculateDateRecolte(date_plant:String, name:String): String = {
    val conn = db.getConnection()
    try {
      val statement = conn.createStatement()
      val query = "SELECT temps_maturite FROM plante_type WHERE nom='" + name + "';"
      val res = statement.executeQuery(query)
      var temps: Int = -1
      while (res.next()) {
        temps = res.getInt(1)
      }
      temps match {
        case -1 => ""
        case _ => {
          val date = stringToDate(date_plant)
          Logger.info("DATE : "+date)
          val format = new java.text.SimpleDateFormat("yyyy-MM-dd")
          format.format(date.plusDays(temps).toDate)
        }
      }
    }
    catch {
      case e:Exception =>{
        e.printStackTrace()
        Logger.info("La récupération du temps de maturité n'a pu s'effectuer, trying again")
        ""
      }
    }
    finally conn.close()
  }

  /**
    * @param str la date sous forme de String (respectant la casse YYYY-MM-DD)
    * @return la date donnée en paramètre au format DateTime
    */
  private def stringToDate(str:String):DateTime={
    val year = str.take(4).toInt
    val month = str.take(7).takeRight(2).toInt
    val day = str.takeRight(2).toInt
    Logger.info("YEAR : "+year)
    Logger.info("MONTH : "+month)
    Logger.info("Day : " +day)
    new DateTime(year, month, day, 0, 0, 0, 0)
  }

  private def dateToString(date:java.sql.Date):String = {
    val df:DateFormat = new SimpleDateFormat("yyyy-MM-dd")
    df.format(date)
  }



  private def getEmplacementListe(id:String):String = {
    val conn = db.getConnection()
    try{
      val statement = conn.createStatement()
      val query = "SELECT lat, longitude FROM emplacement WHERE free='0' AND id='"+id+"';"
      val res = statement.executeQuery(query)
      if(res.next()){
        val s : String = """, "lat" : "%f", "longitude" : "%f" }"""
        s.format(res.getDouble(1), res.getDouble(2))
      }
      else{
        " }"
      }
    }
    catch {
      case e:Exception => {
        e.printStackTrace()
        Logger.info("ERROR, Abort.")
        " }"
      }
    }
    finally conn.close()
  }


  private def isDatetimeAfterDate(dateTime: DateTime, date : DateTime): Boolean ={
    val yearDT:Int = dateTime.getYear
    val monthDT:Int = dateTime.getMonthOfYear
    val dayDT:Int = dateTime.getDayOfMonth
    val year :Int = date.getYear
    val month:Int = date.getMonthOfYear
    val day:Int = date.getDayOfMonth
    if(yearDT < year){
      false
    }else if(yearDT > year)
      true
    else{
      if(monthDT < month)
        false
      else if(monthDT > month)
        true
      else{
        if(dayDT < day)
          false
        else true
      }
    }
  }

}
