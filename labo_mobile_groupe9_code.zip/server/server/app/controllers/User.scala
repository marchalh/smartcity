package controllers

import java.io.DataOutputStream
import java.net.Socket
import javax.inject.Inject

import play.api.Logger
import play.api.db.{Database, NamedDatabase}
import play.api.libs.json.{JsValue, Json}
import play.api.libs.ws._
import play.api.mvc.{Action, Controller}

import scala.concurrent.Future


/**
  * Created by Makarov on 25-04-17.
  */
class User @Inject()(db: Database) (ws: WSClient) extends Controller{

  val SOCKET_NBR = 6789

  /**
    * This method will check if the credentials of the user trying to login are correct and to login.
    * @return Ok.withSession(id) if the login went well (id and pwd recognized), BadRequest Otherwise.
    */
  def login() = Action { request =>
    Logger.info("Tentative de Login")
    val conn = db.getConnection()
    request.body.asJson match {
      case Some(x) => {
        x match {
          case null => BadRequest("Pas de login ni pwd")
          case _ => {
            try{
              //Getting id and pwd from JSON
              val id: String = (x \"id").as[String]
              val pwd: String = (x \"password").as[String]
              val statement = conn.createStatement()
              val sql_req: String = "SELECT admin, rfid_tag_nbr FROM users WHERE id='" + id + "' AND password='"+pwd+"';"
              val res = statement.executeQuery(sql_req)
              if (res.next()) {
                val admin = res.getInt(1)
                val rfid:String = res.getString(2)
                val str:String = """{ "admin" : "%d", "rfid" : "%s" }"""
                val string = str.format(admin, rfid)
                if(admin == 0){
                  Logger.info("Done. Logged user.")
                  Ok(Json.parse(string)).withSession("Connected" -> id)
                }else{
                  val s:String = "%d"
                  val ad = s.format(admin)
                  Logger.info("Done. Logged admin.")
                  Ok(Json.parse(string)).withSession("Connected" -> id, "admin" -> ad)
                }
              } else {
                Logger.info("NOT FOUND : Abort.")
                NotFound("Crendentials not recognized")
              }
            }
            catch{
              case e:Exception => {
                e.printStackTrace()
                InternalServerError("Erreur interne @"+this.getClass)
              }
            }
            finally{
              conn.close()
            }
          }
        }
      }
      case None => {
        Logger.info("BAD REQUEST : Abort.")
        BadRequest("Aucun élément JSON trouvé dans le corps de la requête.")
      }
    }
  }

  /**
    * This method will add a new user in the user db (user is not gonna be admin and a unique auto-generated rfid is
    * gonna be created). Please note that a user rfid tag will always start by "u".
    *
    * @return Ok, badRequest or InternalServerError
    */
  def inscriptionUser = Action{request =>
    Logger.info("Inscription d'un nouveau membre (user)")
    request.body.asJson match{
      case Some(x) =>{
        x match{
          case null => BadRequest("Pas de données")
          case _ => {
            val conn = db.getConnection()
            try{
              //Getting fields from JSON and setting data
              val id:String= (x \"id").as[String]
              val forename:String = (x \"forename").as[String]
              val name:String = (x \"name").as[String]
              val password:String = (x \"password").as[String]
              val adresse:String = (x \"adresse").as[String]
              val rfid:String = "u" + generateRFID()
              val admin:Int = 0
              //Setting DB connection
              val statement = conn.createStatement()
              val s:String ="INSERT INTO users VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%d');"
              val req_sql = s.format(id, rfid, forename, name, password, adresse, admin)
              val res = statement.execute(req_sql)
              if (!res) {
                sendRfidToPi(rfid, admin)
                val s:String = """{ "rfid" : "%s" }"""
                val str = s.format(rfid)
                Logger("Done.")
                Ok(Json.parse(str))
              } else {
                Logger.info("NOT FOUND : Abort.")
                NotFound("L'utilisateur n'a pas pu être inscrit")
              }
            }
            catch{
              case e:Exception => {
                e.printStackTrace()
                InternalServerError("Erreur interne @"+this.getClass)
              }
            }
            finally{
              conn.close()
            }
          }
        }
      }
      case None => {
        Logger.info("BAD REQUEST : Abort.")
        BadRequest("Pas de données dans le corps de la requête.")
      }
    }

  }


    /**
      * This method will add a new user in the user db (user is gonna be admin and a unique auto-generated rfid is
      * gonna be created). Please note that an admin rfid tag will always start by "a".
      * @return Ok, badRequest or InternalServerError
      */
    def inscriptionAdmin = Action{request =>
      Logger.info("Inscription d'un nouveau membre (admin)")
      request.body.asJson match{
        case Some(x) =>{
          x match{
            case null => BadRequest("Pas de données")
            case _ => {
              val conn = db.getConnection()
              try{
                //Getting fields from JSON and setting data
                val id:String= (x \"id").as[String]
                val forename:String = (x \"forename").as[String]
                val name:String = (x \"name").as[String]
                val password:String = (x \"password").as[String]
                val adresse:String = (x \"adresse").as[String]
                val rfid:String = "a" + generateRFID()
                val admin:Int = 1
                //Setting DB connection
                val statement = conn.createStatement()
                val s:String ="INSERT INTO users VALUES ('%s', '%s', '%s', '%s', '%s', '%s', '%d');"
                val req_sql = s.format(id, rfid, name, forename, password, adresse, admin)
                val res = statement.execute(req_sql)
                if (res) {
                  sendRfidToPi(rfid, admin)
                  val s:String = """{ "rfid" : "%s" }"""
                  val str = s.format(rfid)
                  Logger("Done.")
                  Ok(Json.parse(str))
                } else {
                  Logger.info("NOT FOUND : Abort.")
                  NotFound("L'utilisateur n'a pas pu être inscrit")
                }
              }
              catch{
                case e:Exception => {
                  e.printStackTrace()
                  InternalServerError("Erreur interne @"+this.getClass)
                }
              }
              finally{
                conn.close()
              }
            }
          }
        }
        case None => {
          Logger.info("BAD REQUEST : Abort.")
          BadRequest("Pas de données dans le corps de la requête.")
        }
      }
    }


  /**
    *
    * @return Ok and discards the session.
    */
  def logout()= Action{request =>
    Logger("LOGGED OUT.")
    Ok("Bye").withNewSession
  }


  /**
    * This method will auto-generate an RFID Tag and make sure it is unique.
    * Please note that the Tag will be 31 char long to be 32 in the end (as a 'a' or 'u' stands at the string's head).
    * @return the unique tag
    */
  private def generateRFID():String = {
    checkTag(makeStringTag())
  }

  /**
    * This method will randomly generate a tag using chars from 'a' to 'z' (also caps) and numbers.
    * @return the random tag.
    */
  private def makeStringTag():String = {
    //Defining the length and the set of chars from which to build.
    val length:Int = 31
    val chars = ('a' to 'z') ++ ('A' to 'Z') ++ ('0' to '9')
    //Treatment
    val sb = new StringBuilder
    for (i <- 1 to length) {
      val randomNum = util.Random.nextInt(chars.length)
      sb.append(chars(randomNum))
    }
    sb.toString
  }

  /**
    *
    * @param tag the String tag to check the unicity of (check via db, users table).
    * @return
    */
  private def checkTag(tag:String):String = {
    val conn = db.getConnection()
    try{
      val statement = conn.createStatement()
      val query = "SELECT id FROM users where rfid_tag_nbr='"+tag+"';"
      val res = statement.executeQuery(query)
      var counter = true
      while(res.next()){
        counter = false
      }
      if (counter) {
        tag
      } else {
        generateRFID()
      }
    }
    catch{
      case e:Exception =>{
        e.printStackTrace()
        Logger.info("Une erreur interne est survenue lors du check du rfid, trying again")
        generateRFID()
      }
    }
    finally{
      conn.close()
    }
  }


  /**
    * Envoit le nouveau rfid aux différents raspberry pis.
    * @param tag
    * @param admin
    */
  private def sendRfidToPi(tag:String, admin:Int)={
    val conn = db.getConnection()
    try{
      val data = Json.obj("rfid_tag_nbr" -> tag, "admin" -> admin)
      val statement = conn.createStatement()
      val query = "SELECT raspberry_id FROM emplacement;"
      val res = statement.executeQuery(query)
      while(res.next())
        sendOnSocket(Json.stringify(data),res.getString(1))
    }
    catch{
      case e:Exception =>{
        Logger.info("Une erreur interne est survenue lors du chargement des adresses des pi, trying again")
      }
    }
    finally  conn.close()
  }


  def sendOnSocket(message: String, sender:String): Unit ={
    val socket:Socket = new Socket("localhost",SOCKET_NBR)
    var dataout:DataOutputStream = new DataOutputStream(socket.getOutputStream)
    dataout.writeBytes(message)
    //var buf:BufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream))
    //val fromRPI:String = buf.readLine()
  }
}
