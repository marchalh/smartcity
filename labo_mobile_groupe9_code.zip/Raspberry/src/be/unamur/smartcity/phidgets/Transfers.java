package be.unamur.smartcity.phidgets;

import okhttp3.*;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import static be.unamur.smartcity.phidgets.Database.firstInsertUser;

/**
 * This method will be used to send requests (GET or POST) to a certain URL.
 * Created by Makarov on 30-04-17.
 */
public class Transfers {

    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");
    public static final String hostName = "";
    public static final int portNumber = 6789;
    public static final String responseRFIDReq = "";

    static final String LOST_CONNECTION_PHIDGET = "http://192.168.137.1:9000/emplacement/connexion/";
    static final String LISTER_USER_URL = "http://192.168.137.1:9000/users/lister";
    static final String LISTER_EMPLACEMENTS_URL = "http://192.168.137.1:9000/terrain/emplacements";
    static final String UPDATE_PHIDGET_URL = "http://192.168.137.1:9000/emplacement/update/";

    /**
     * Works ASYNC
     * @param url the url to which the request is sent
     * @param data the data in the body of the request (JSON format).
     * @return The content of the response's body (as String).
     * @throws IOException
     */
    public static void firePostRequest(final String url, String data) throws IOException {
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS);
        builder.writeTimeout(30, TimeUnit.SECONDS);
        OkHttpClient client = builder.build();
        RequestBody body = RequestBody.create(JSON, data);
        Request request = new Request.Builder()
                .url(url)
                .post(body)
                .build();
        client.newCall(request)
                .enqueue(new Callback() {
                    @Override
                    public void onFailure(final Call call, IOException e) {
                        System.out.println("La requête n'a pas abouti : " + e.getMessage());
                        // Error

                    }

                    @Override
                    public void onResponse(Call call, final Response response) throws IOException {
                        if (url.contains(UPDATE_PHIDGET_URL)||url.contains(LOST_CONNECTION_PHIDGET)) {
                            JSONParser parser = new JSONParser();
                                String responseData = response.body().string();
                                try {
                                    JSONObject json = new JSONObject((Map) parser.parse(responseData));
                                    // Do something here
                                    Action.getActions(json);
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                }

                            // Do something with the response
                        }
                    }
                });
    }

    /**
     * Works SYNC
     * @param url the url to which the request is sent
     * @return The content of the response's body (as String).
     * @throws IOException
     */
    public static String fireGetRequest(String url) throws IOException {

        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        builder.connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS);
        builder.writeTimeout(30, TimeUnit.SECONDS);
        OkHttpClient client = builder.build();
        Request request = new Request.Builder()
                .url(url)
                .build();

        Response response = client.newCall(request).execute();
        return response.body().string();
    }

    /**
     *
     */
    public static void socketListener(){
        ServerSocket welcomeSocket = null;
        try {
            String request;
            welcomeSocket = new ServerSocket(portNumber);
            Boolean noError = true;
            while(noError){
                Socket connectionSocket = welcomeSocket.accept();
                System.out.println("Handling remote client at " +
                        connectionSocket.getInetAddress().getHostAddress() + " on port " +
                        connectionSocket.getPort() + " from " +
                        InetAddress.getLocalHost().getHostAddress() + " on port " +
                        connectionSocket.getLocalPort());
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
                DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
                request = inFromClient.readLine();
                treatingIncomingRequest(request);
                outToClient.writeBytes(responseRFIDReq);
            }
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {
            try {
                welcomeSocket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }


    private static void treatingIncomingRequest(String request){
        try {
            JSONParser parser = new JSONParser();
            JSONObject obj = (JSONObject) parser.parse(request);
            //The User is initially never inside the Terrain.
            firstInsertUser(new User((String)obj.get("rfid_tag_nbr"), (Integer)obj.get("admin"),0));
        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

}
