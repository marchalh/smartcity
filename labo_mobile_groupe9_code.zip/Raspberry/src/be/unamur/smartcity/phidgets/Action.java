package be.unamur.smartcity.phidgets;

import org.json.simple.JSONObject;

import java.util.HashMap;

import static be.unamur.smartcity.phidgets.Main.*;
import static be.unamur.smartcity.phidgets.ServoMotors.arroser;
import static be.unamur.smartcity.phidgets.ServoMotors.closeWindow;
import static be.unamur.smartcity.phidgets.ServoMotors.openWindow;

/**
 * Created by Makarov on 10-05-17.
 */
public class Action {

    public static void getActions(JSONObject json){
        //GET ACTIONS TO DO
        HashMap<String, String> actions = new HashMap<>();
        actions.put("luminosite", (String) json.get("luminosite"));
        actions.put("ph", (String) json.get("ph"));
        actions.put("humidite", (String) json.get("humidite"));
        actions.put("temperature", (String) json.get("temperature"));
        //DO ACTIONS
        actionLuminosite(actions.get("luminosite"));
        actionPh(actions.get("ph"));
        actionHumidite(actions.get("humidite"));
        actionTemperature(actions.get("temperature"));
    }


    public static void actionLuminosite(String act){
        switch(act){
            case "plus" :{
                //TODO (OUVRIR LA LAMPE) SI (LE VOLET EST OUVERT)
                System.out.println("La luminosité doit être augmentée.");
                lampOn();
                //openVolet();
                /* code avec le volet !
                if (Boolean x = getOutput (5,

                 */
                break;
            }
            case "moins": {
                //TODO (FERMER LA LAMPE) ET (FERMER LE VOLET)
                System.out.println("La luminosité doit être diminuée.");
                lampOff();
                //closeVolet();
                break;
            }
            default : {
                System.out.println("La luminosité est dans les normes");
                break;
            }
        }
    }

    public static void actionPh(String act){
        switch(act){
            case "plus" :{
                //TODO FAIRE AUGMENTER LE PH.
                System.out.println("Le ph doit être augmenté.");
                break;
            }
            case "moins": {
                //TODO FAIRE DIMINUER LE PH
                System.out.println("Le ph doit être diminué");
                break;
            }
            default : {
                System.out.println("Le ph est dans les normes.");
                break;
            }
        }

    }
    public static void actionHumidite(String act){
        switch(act){
            case "plus" :{
                System.out.println("L'humidité doit être augmentée.");
                //ARROSER
                try {
                    arroser();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case "moins": {
                System.out.println("L'humidité doit être diminuée.");
                //OUVRIR L'AERATION
                try {
                    openWindow();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            default : {
                System.out.println("L'humidité est dans les normes.");
                break;
            }
        }

    }
    public static void actionTemperature(String act){
        switch(act){
            case "plus" :{
                System.out.println("La température doit être augmentée.");
                //TODO (FERMER L'AERATION) OU FAIRE CHAUFFER.
                try {
                    closeWindow();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            case "moins": {
                System.out.println("La température doit être diminuée.");
                //OUVRIR AERATION.
                try {
                    openWindow();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                break;
            }
            default : {
                System.out.println("La température est dans les normes.");
                break;
            }
        }

    }
}
