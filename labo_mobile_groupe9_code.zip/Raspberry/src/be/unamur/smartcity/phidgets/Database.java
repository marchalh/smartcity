package be.unamur.smartcity.phidgets;

import com.sun.media.jfxmedia.logging.Logger;
import javafx.util.Pair;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.h2.jdbcx.JdbcDataSource;

import java.io.IOException;
import java.sql.*;

import static be.unamur.smartcity.phidgets.Transfers.fireGetRequest;
import static be.unamur.smartcity.phidgets.Transfers.firePostRequest;

/**
 * Created by makarov on 30.04.17.
 * This class will be used to create the database of the RPI.
 */
public class Database {

    static final String SERVER_URL = "192.168.137.1:9000";
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "org.h2.Driver";
    static final String DB_URL = "jdbc:h2:mem:rpi;DB_CLOSE_DELAY=-1;DATABASE_TO_UPPER=false";

    static final String LISTER_USER_URL = "http://192.168.137.1:9000/users/lister";
    static final String LISTER_EMPLACEMENTS_URL = "http://192.168.137.1:9000/terrain/emplacements";
    static final String UPDATE_PHIDGET_URL = "http://192.168.137.1:9000/emplacement/update/";
    //  Database credentials
    static final String USER = "username";
    static final String PASS = "password";

    public static void createDatabase(){
        Statement statement = null;
        Statement stmt = null;
        Connection conn = null;
        Connection connection = null;
        try{
            //Registering JDBC driver
            Class.forName(JDBC_DRIVER);

            JdbcDataSource ds = new JdbcDataSource();
            ds.setURL(DB_URL);
            ds.setUser(USER);
            ds.setPassword(PASS);

            connection = DriverManager.getConnection(DB_URL,USER,PASS);
            //Opening a connection
            System.out.println("Connecting to database...");

            //Executing creation
            System.out.println("Creating database...");
            System.out.println(connection.getAutoCommit());
            statement = connection.createStatement();

            //Creating tables
            System.out.println("Creating tables...");
            String users = "CREATE TABLE users (rfid varchar(60) primary key, admin tinyint, is_inside tinyint)";
            String terrain = "CREATE TABLE terrain (" +
                    "emplacement VARCHAR(255) not null," +
                    "luminosite float," +
                    "ph float," +
                    "humidite float," +
                    "temperature float," +
                    "PRIMARY KEY (emplacement));";
            boolean set = statement.execute("CREATE TABLE users (rfid varchar(60) primary key, admin tinyint, is_inside tinyint)");
            if(set){
                System.out.println("Table users could not be created");
            }
            set = statement.execute(terrain);
            if(set) {
                System.out.println("Table Terrain could not be created");
            }

            //Inserting data Inside database.
            boolean res = fillDatabase();
        }catch(SQLException se){
            //Handle errors for JDBC
            se.printStackTrace();
        }catch(Exception e){
            //Handle errors for Class.forName
            e.printStackTrace();
        }finally{
            try{
                if(connection!=null)
                    connection.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
            try{
                if(statement!=null)
                    statement.close();
            }catch(SQLException se2){
            }

        }
        System.out.println("Goodbye!");
    }


    private static boolean fillDatabase(){
        try {
            JSONParser jsonParser = new JSONParser();
            //GET user data
            JSONObject userData = (JSONObject) jsonParser.parse(fireGetRequest(LISTER_USER_URL));
            //GET Terrain Data
            JSONObject terrainData = (JSONObject) jsonParser.parse(fireGetRequest(LISTER_EMPLACEMENTS_URL));

            JSONArray userArray = (JSONArray) userData.get("utilisateurs");
            JSONArray terrainArray = (JSONArray) terrainData.get("emplacements");

            //Filling db for USER
            for (Object anUserArray : userArray) {
                JSONObject object = (JSONObject) anUserArray;
                //The User is initially never inside the terrain.
                User user = new User((String) object.get("rfid_tag_nbr"), Integer.valueOf((String) object.get("admin")),
                        0);

                firstInsertUser(user);
            }

            for (Object aTerrainArray : terrainArray) {
                JSONObject object = (JSONObject) aTerrainArray;
                firstInsertTerrain((String)object.get("id"));
            }
        } catch (IOException e) {
            e.printStackTrace();
            Logger.logMsg(0, "Error sending HTTP GET request to get data.");
        } catch (ParseException e) {
            e.printStackTrace();
            Logger.logMsg(0, "Could not parse object");
        }
        return true;
    }

    /*
        FIRST INSERT IN DB
     */

    /**
     * @param user the User to insert into DB.
     */
    public static void firstInsertUser(User user){
        String query = "INSERT INTO users (rfid, admin, is_inside) VALUES ('"+user.getRfid()+"', '"+user.isAdmin()+"', '"+user.isIs_inside()+"');";
        Statement statement = null;
        Connection conn = null;
        ResultSet rs = null;
        System.out.println("RFID : "+user.getRfid());
        System.out.println("ADMIN : "+user.isAdmin());
        System.out.println("INSIDE : "+user.isIs_inside());
        try{
            JdbcDataSource ds = new JdbcDataSource();
            ds.setURL(DB_URL);
            ds.setUser(USER);
            ds.setPassword(PASS);
            conn = ds.getConnection();
            statement = conn.createStatement();
            boolean res = statement.execute(query);
            if(res) {
                String querysql = "SELECT * FROM users WHERE rfid='"+user.getRfid()+"';";
                rs = statement.executeQuery(querysql);
                if(!rs.next()){
                    Logger.logMsg(0, "Could not insert a User in DB, trying again.");
                    firstInsertUser(user);
                }else
                    System.out.println("INSERT DONE.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            Logger.logMsg(0, "Could not set User into DB");
        }
        finally{
            try{
                if(rs!=null)
                    rs.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try{
                if(statement!=null)
                    statement.close();
            }catch(SQLException se2){
            }// nothing we can do
            try{
                if(conn!=null)
                    conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }



    public static void firstInsertTerrain(String id){
        String query = "INSERT INTO terrain VALUES ('"+id+"', '-1', '-1', '-1', '-1');";
        System.out.println("TERRAIN ID : "+id);
        Statement statement = null;
        Connection conn = null;
        ResultSet rs = null;
        try{
            JdbcDataSource ds = new JdbcDataSource();
            ds.setURL(DB_URL);
            ds.setUser(USER);
            ds.setPassword(PASS);
            conn = ds.getConnection();
            statement = conn.createStatement();
            boolean res = statement.execute(query);
            if(res)
                System.out.println("INSERT DONE.");
        } catch (SQLException e) {
            e.printStackTrace();
            Logger.logMsg(0, "Could not set Terrain into DB");
        }
        finally{
            try{
                if(statement!=null)
                    statement.close();
            }catch(SQLException se2){
            }// nothing we can do
            try{
                if(conn!=null)
                    conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }




    /*
        UPDATE TABLES ONLY.
     */
    /**
     * This method will update the data phidget in the db and fire the POST request to the Server.
     * @param terrain the terrain to update the phidget data
     */
    public static void updateTerrain(Terrain terrain){
        String query = "UPDATE terrain SET luminosite='"+terrain.getLuminosite()+"', ph='"+
                terrain.getPh()+"', humidite='"+terrain.getHumidite()+"', temperature='"+terrain.getTemperature()+"'" +
                " WHERE emplacement='"+terrain.getEmplacement()+"';";
        Statement statement = null;
        Connection conn = null;
        try{
            JdbcDataSource ds = new JdbcDataSource();
            ds.setURL(DB_URL);
            ds.setUser(USER);
            ds.setPassword(PASS);
            conn = ds.getConnection();
            statement = conn.createStatement();
            statement.execute(query);
            //Firing the Request
            String url = UPDATE_PHIDGET_URL+terrain.getEmplacement();
            String data = "{ " +
                    "\"emplacement\" : \""+terrain.getEmplacement()+"\", "+
                    "\"luminosite\" : \""+terrain.getLuminosite()+"\", "+
                    "\"ph\": \""+terrain.getPh()+"\", "+
                    "\"humidite\" : \""+terrain.getHumidite()+"\", "+
                    "\"temperature\" : \""+terrain.getTemperature()+"\", "+
                    "\"chemical\" : \"null\" }";
            firePostRequest(url,data);

        } catch (SQLException e) {
            e.printStackTrace();
            Logger.logMsg(0, "Could not set Terrain into DB");
        } catch (IOException e) {
            e.printStackTrace();
        }finally{
            try{
                if(statement!=null)
                    statement.close();
            }catch(SQLException se2){
            }// nothing we can do
            try{
                if(conn!=null)
                    conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
        }
    }

    /*
        GET DATA FROM DB.
     */

    public static Pair<Boolean, Integer> getUserRfid(String rfid){
        String query = "SELECT admin FROM users WHERE rfid='"+rfid+"';";
        Pair<Boolean, Integer> pair = null;
        Statement statement = null;
        Connection conn = null;
        ResultSet res = null;
        try{
            JdbcDataSource ds = new JdbcDataSource();
            ds.setURL(DB_URL);
            ds.setUser(USER);
            ds.setPassword(PASS);
            conn = ds.getConnection();
            statement = conn.createStatement();
            res = statement.executeQuery(query);
            boolean isEmpty = true;
            if(res.next()) {
                isEmpty = false;
                int admin = res.getInt("admin");
                pair = new Pair<>(isEmpty,admin);
            }
            else
                pair = new Pair<>(isEmpty, 0);
        } catch (SQLException e) {
            e.printStackTrace();
            Logger.logMsg(0, "Could not set Terrain into DB");
        }
        finally{
            try{
            if(res!=null){
                res.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
            try{
                if(statement!=null)
                    statement.close();
            }catch(SQLException se2){
            }// nothing we can do
            try{
                if(conn!=null)
                    conn.close();
            }catch(SQLException se){
                se.printStackTrace();
            }
            return pair;
        }
    }




}




