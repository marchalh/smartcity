package be.unamur.smartcity.phidgets;

import com.phidgets.AdvancedServoPhidget;
import com.phidgets.Phidget;
import com.phidgets.event.*;

/**
 * Created by Amélie on 04-04-17.
 */
public class ServoMotors {

    //ser 305848 gere l'ouverture et fermeture de la fenetre ( pos 0 : lock, pos 180: unlock
    //ser 306937 gere arrosage (pos 180: reservoir stable, pos 60: verse le contenu du reservoir
    public static final void actionServo(int ser, int pos) throws Exception {
        AdvancedServoPhidget servo;


        System.out.println(Phidget.getLibraryVersion());


        servo = new AdvancedServoPhidget();
        servo.addAttachListener(new AttachListener() {
            public void attached(AttachEvent ae) {
                System.out.println("attachment of " + ae);
            }
        });
        servo.addDetachListener(new DetachListener() {
            public void detached(DetachEvent ae) {
                System.out.println("detachment of " + ae);
            }
        });
        servo.addErrorListener(new ErrorListener() {
            public void error(ErrorEvent ee) {
                System.out.println("error event for " + ee);
            }
        });
        servo.addServoPositionChangeListener(new ServoPositionChangeListener()
        {
            public void servoPositionChanged(ServoPositionChangeEvent oe)
            {
                System.out.println(oe);
            }
        });

        servo.open(ser);
        System.out.println("waiting for AdvancedServo attachment...");
        servo.waitForAttachment();

        System.out.println("Serial: " + servo.getSerialNumber());
        System.out.println("Servos: " + servo.getMotorCount());

        //Initialize the Advanced Servo
        servo.setEngaged(0, false);
        servo.setSpeedRampingOn(0, false);

        servo.setEngaged(0, true);
        Thread.sleep(500);

        servo.setSpeedRampingOn(0, true);
        servo.setAcceleration(0,servo.getAccelerationMin(0));
        servo.setVelocityLimit(0, 200);

        //on modifie la position ici
        servo.setPosition(0, pos);

        System.out.println();
        servo.close();
        servo = null;
    }
    //closeWindow va fermer la fenetre grace au servo
    public static final void closeWindow() throws Exception {
        actionServo(305848,180);
    }
    //closeWindow va ouvrir la fenetre grace au servo
    public static final void openWindow() throws Exception {
        actionServo(305848,0);
    }

    //arroser va abaisser le reservoir et verser son contenu puis redresse le reservoir
    public static final void arroser() throws Exception {
        actionServo(306937,60);
        Thread.sleep(6000);
        actionServo(306937,180);
    }

}
