package be.unamur.smartcity.phidgets;

/**
 * Created by Syméon Sforza on 11-05-17.
 */
import com.phidgets.*;
import com.phidgets.event.*;
import javafx.util.Pair;

import static be.unamur.smartcity.phidgets.Database.getUserRfid;

public class AdaptRFID
{
    public static final void lectureRFID(RFIDPhidget rfid) throws Exception {


        System.out.println(Phidget.getLibraryVersion());

        rfid = new RFIDPhidget();
        rfid.addAttachListener(new AttachListener() {
            public void attached(AttachEvent ae)
            {
                try
                {
                    ((RFIDPhidget)ae.getSource()).setAntennaOn(true);
                    ((RFIDPhidget)ae.getSource()).setLEDOn(true);
                }
                catch (PhidgetException ex) { }
                System.out.println("attachment of " + ae);
            }
        });
        rfid.addDetachListener(new DetachListener() {
            public void detached(DetachEvent ae) {
                System.out.println("detachment of " + ae);
            }
        });
        rfid.addErrorListener(new ErrorListener() {
            public void error(ErrorEvent ee) {
                System.out.println("error event for " + ee);
            }
        });
        rfid.addTagGainListener(new TagGainListener()
        {
            public void tagGained(TagGainEvent oe)
            {
                System.out.println("Tag Gained: " +oe.getValue() + " (Proto:"+ oe.getProtocol()+")");

              //  On check si son rfid est bien dans la bd si oui il peut rentrer

                Pair<Boolean, Integer> pair = getUserRfid(oe.getValue());
                if (pair.getKey())
                {
                    System.out.println("Bienvenu cher " + oe.getValue() + "!");
                }
                else {
                    System.out.println("Circulez, il n'y a rien à voir !");
                }
            }

        });
        rfid.addTagLossListener(new TagLossListener()
        {
            public void tagLost(TagLossEvent oe)
            {
                System.out.println(oe);
            }
        });
        rfid.addOutputChangeListener(new OutputChangeListener()
        {
            public void outputChanged(OutputChangeEvent oe)
            {
                System.out.println(oe);
            }
        });

        rfid.openAny();
        System.out.println("waiting for RFID attachment...");
        rfid.waitForAttachment();

        System.out.println("Serial: " + rfid.getSerialNumber());
        System.out.println("Outputs: " + rfid.getOutputCount());

        //How to write a tag:
        //rfid.write("A TAG!!", RFIDPhidget.PHIDGET_RFID_PROTOCOL_PHIDGETS, false);

//        System.out.println("Outputting events.  Input to stop.");
//        System.in.read();
//        System.out.print("closing...");
//        rfid.close();
//        rfid = null;
//        System.out.println(" ok");
//        if (false) {
//            System.out.println("wait for finalization...");
//            System.gc();
//        }
    }
}

