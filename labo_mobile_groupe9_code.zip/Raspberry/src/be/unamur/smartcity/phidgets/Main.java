package be.unamur.smartcity.phidgets;

import com.phidgets.AdvancedServoPhidget;
import com.phidgets.InterfaceKitPhidget;
import com.phidgets.PhidgetException;
import com.phidgets.RFIDPhidget;
import com.phidgets.event.*;

import java.io.IOException;

import static be.unamur.smartcity.phidgets.Database.*;
import static be.unamur.smartcity.phidgets.AdaptRFID.lectureRFID;
import static be.unamur.smartcity.phidgets.Transfers.LOST_CONNECTION_PHIDGET;
import static be.unamur.smartcity.phidgets.Transfers.firePostRequest;
import static be.unamur.smartcity.phidgets.Transfers.socketListener;

/**
 * Created by Amélie on 03-04-17.
 */
public class Main {

    private static InterfaceKitPhidget interfaceKit;
    private static AdvancedServoPhidget servo;

    private static int lux;
    private static double degre;
    private static double pH;
    private static double humide;

    private static boolean tourne = true;

    private static RFIDPhidget rfidPhidget;

    public static void main(String[] args) {

        //While true quelque part
        try {
            //Creating and Setting values in the DB
            createDatabase();
            //Starting the Thread to listen to ports (to get RFID updates).
            Thread t1 = new Thread(new Runnable() {
                public void run() {
                    socketListener();
                }
            });
            t1.start();


            interfaceKit = new InterfaceKitPhidget();

            listeners(interfaceKit);

            // INITIALISATION DU RFID
            try {
                lectureRFID(rfidPhidget);
            } catch (Exception e) {
                e.printStackTrace();
            }


            Thread.sleep(500);

                //WAIT FOR ALL DEVICES TO BE ATTACHED
                interfaceKit.openAny();

                System.out.println("Wait for InterfaceKit attachment...");
                interfaceKit.waitForAttachment();


                Thread.sleep(500);

                if (false) {
                    System.out.println("Closing...");
                    System.out.flush();
                    interfaceKit.close();

                    System.out.println("Opening...");
                    interfaceKit.openAny();
                    System.out.println("Ok");

                    interfaceKit.waitForAttachment();
                }

                while (tourne) {

                    //ENVOYER LES DONNEES AU SERVEUR TOUS LES X TEMPS
                    System.out.println("Data :\nLight : " + lux + "\nTemp : " + degre + "\npH : " + pH + "\nHumidity : "
                            + humide + "\n");
                    //TODO SET EMPLACEMENT
                    Terrain terrain = new Terrain("e03", (float) lux, (float) pH, (float) humide, (float) degre);
                    updateTerrain(terrain);
                    Thread.sleep(20000);

                }


            //Important de fermer
            interfaceKit.close();
            interfaceKit = null;

        } catch (PhidgetException e) {
            e.printStackTrace();
            System.out.println("Problem with connection...");
        } catch (InterruptedException e) {
            e.printStackTrace();
            System.out.println("Problem with Thread...");
        }
    }

    private static void listeners(InterfaceKitPhidget interfaceKit) {
        interfaceKit.addAttachListener(new AttachListener() {
            @Override
            public void attached(AttachEvent attachEvent) {
                System.out.println("Attach of " + attachEvent);
            }
        });

        interfaceKit.addDetachListener(new DetachListener() {
            @Override
            public void detached(DetachEvent detachEvent) {
                try {
                    firePostRequest(LOST_CONNECTION_PHIDGET+"e03", "");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                System.out.println("Detach of " + detachEvent);
            }
        });

        interfaceKit.addErrorListener(new ErrorListener() {
            @Override
            public void error(ErrorEvent errorEvent) {
                System.out.println("Error : " + errorEvent);
            }
        });

        interfaceKit.addInputChangeListener(new InputChangeListener() {
            @Override
            public void inputChanged(InputChangeEvent inputChangeEvent) {
                System.out.println("Input change : " + inputChangeEvent);
            }
        });

        interfaceKit.addOutputChangeListener(new OutputChangeListener() {
            @Override
            public void outputChanged(OutputChangeEvent outputChangeEvent) {
                System.out.println("Output change : " + outputChangeEvent);
            }
        });

        interfaceKit.addSensorChangeListener(new SensorChangeListener() {
            @Override
            public void sensorChanged(SensorChangeEvent sensorChangeEvent) {
                //System.out.println("Sensor change : " + sensorChangeEvent);

                int val = sensorChangeEvent.getValue();

                switch (sensorChangeEvent.getIndex()) {
                    case 0:{
                        if (val == 0) {
                            //Todo : Send message to notify the sensor detached
                            System.out.println("SEND LOST MESSAGE");
                        }

                        lux = val;
                        System.out.println("Light changed");
                        break;}
                    case 1:{
                        if (val == 0) {
                            //Todo : Send message to notify the sensor detached

                            System.out.println("SEND LOST MESSAGE");
                        }

                        degre = (val * 0.2222) - 61.111;
                        System.out.println("Temp changed");
                        break;}
                    case 2:{
                        if (val == 0) {
                            //Todo : Send message to notify the sensor detached
                            System.out.println("SEND LOST MESSAGE");
                        }

                        pH = 0.0178 * val - 1.889;
                        System.out.println("pH changed");
                        break;}
                    case 3:{
                        if (val == 0) {
                            //Todo : Send message to notify the sensor detached
                            System.out.println("SEND LOST MESSAGE");
                        }

                        humide = (val * 0.1906) - 40.2;
                        System.out.println("Humidity changed");
                        break;}
                }
            }
        });
    }


    // TEST 1 2 1 2

    public static final void stateOutput(int output, boolean x) {

        //InterfaceKitPhidget interfaceKit;

        //While true quelque part
        try {
            interfaceKit.openAny();
            System.out.println("Wait for InterfaceKit attachment...");
            System.out.println("????");
            interfaceKit.waitForAttachment(1000);
            //System.out.println("Version: " +interfaceKit.getDeviceVersion());

            //output
            interfaceKit.setOutputState(output,x);

            //Important de fermer
            interfaceKit.close();


        } catch (PhidgetException e) {
            e.printStackTrace();
            System.out.println("Problem with connection...");
        }
    }

    public static final void lampOn() {

        stateOutput(0, true);
    }

    public static final void lampOff() {


        stateOutput(0, false);
    }

    public static final void closeVolet(){

        stateOutput(5,true);
    }

    public static final void openVolet(){

        stateOutput(5,false);
    }
}



