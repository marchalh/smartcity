package be.unamur.smartcity.phidgets;

/**
 * Created by makarov on 03.05.17.
 */
public class Terrain {

    private String emplacement;
    private float luminosite;
    private float ph;
    private float humidite;
    private float temperature;


    public Terrain(String emplacement, float luminosite, float ph, float humidite, float temperature){
        this.emplacement = emplacement;
        this.luminosite = luminosite;
        this.ph = ph;
        this.humidite = humidite;
        this.temperature = temperature;
    }

    public String getEmplacement() {
        return this.emplacement;
    }

    public float getLuminosite() {
        return this.luminosite;
    }

    public float getPh() {
        return this.ph;
    }

    public float getHumidite() {
        return this.humidite;
    }

    public float getTemperature() {
        return this.temperature;
    }
}
