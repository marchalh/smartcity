package be.unamur.smartcity.phidgets;

/**
 * Created by makarov on 03.05.17.
 */
public class User {

    private String rfid;
    private int admin;
    private int is_inside;

    public User(String rfid, int admin, int is_inside){
        this.rfid = rfid;
        this.admin = admin;
        this.is_inside = is_inside;
    }

    public String getRfid() {
        return rfid;
    }

    public int isAdmin() {
        return admin;
    }

    public int isIs_inside() {
        return is_inside;
    }
}
